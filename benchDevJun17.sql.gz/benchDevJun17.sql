-- MySQL dump 10.11
--
-- Host: localhost    Database: bench
-- ------------------------------------------------------
-- Server version	5.0.95-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exp_accessories`
--

DROP TABLE IF EXISTS `exp_accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_accessories` (
  `accessory_id` int(10) unsigned NOT NULL auto_increment,
  `class` varchar(75) NOT NULL default '',
  `member_groups` varchar(255) NOT NULL default 'all',
  `controllers` text,
  `accessory_version` varchar(12) NOT NULL,
  PRIMARY KEY  (`accessory_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_accessories`
--

LOCK TABLES `exp_accessories` WRITE;
/*!40000 ALTER TABLE `exp_accessories` DISABLE KEYS */;
INSERT INTO `exp_accessories` VALUES (1,'Expressionengine_info_acc','1|5','addons|addons_accessories|addons_extensions|addons_fieldtypes|addons_modules|addons_plugins|admin_content|admin_system|content|content_edit|content_files|content_files_modal|content_publish|design|homepage|members|myaccount|tools|tools_communicate|tools_data|tools_logs|tools_utilities','1.0');
/*!40000 ALTER TABLE `exp_accessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_actions`
--

DROP TABLE IF EXISTS `exp_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_actions` (
  `action_id` int(4) unsigned NOT NULL auto_increment,
  `class` varchar(50) NOT NULL,
  `method` varchar(50) NOT NULL,
  PRIMARY KEY  (`action_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_actions`
--

LOCK TABLES `exp_actions` WRITE;
/*!40000 ALTER TABLE `exp_actions` DISABLE KEYS */;
INSERT INTO `exp_actions` VALUES (1,'Comment','insert_new_comment'),(2,'Comment_mcp','delete_comment_notification'),(3,'Comment','comment_subscribe'),(4,'Comment','edit_comment'),(5,'Metaweblog_api','incoming'),(6,'Safecracker','submit_entry'),(7,'Safecracker','combo_loader'),(8,'Search','do_search'),(9,'Channel','insert_new_entry'),(10,'Channel','filemanager_endpoint'),(11,'Channel','smiley_pop'),(12,'Rte','get_js');
/*!40000 ALTER TABLE `exp_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_captcha`
--

DROP TABLE IF EXISTS `exp_captcha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL auto_increment,
  `date` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `word` varchar(20) NOT NULL,
  PRIMARY KEY  (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_captcha`
--

LOCK TABLES `exp_captcha` WRITE;
/*!40000 ALTER TABLE `exp_captcha` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_captcha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_categories`
--

DROP TABLE IF EXISTS `exp_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_categories` (
  `cat_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_id` int(6) unsigned NOT NULL,
  `parent_id` int(4) unsigned NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_url_title` varchar(75) NOT NULL,
  `cat_description` text,
  `cat_image` varchar(120) default NULL,
  `cat_order` int(4) unsigned NOT NULL,
  PRIMARY KEY  (`cat_id`),
  KEY `group_id` (`group_id`),
  KEY `cat_name` (`cat_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_categories`
--

LOCK TABLES `exp_categories` WRITE;
/*!40000 ALTER TABLE `exp_categories` DISABLE KEYS */;
INSERT INTO `exp_categories` VALUES (1,1,1,0,'Overlays','overlays','','0',3),(2,1,1,0,'Rates','rates','','0',4),(3,1,1,0,'Loan Submissions','loan-submissions','','0',2),(4,1,1,0,'Appraisals','appraisals','','0',1);
/*!40000 ALTER TABLE `exp_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_category_field_data`
--

DROP TABLE IF EXISTS `exp_category_field_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_category_field_data` (
  `cat_id` int(4) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_id` int(4) unsigned NOT NULL,
  `field_id_1` text,
  `field_ft_1` varchar(40) default 'none',
  PRIMARY KEY  (`cat_id`),
  KEY `site_id` (`site_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_category_field_data`
--

LOCK TABLES `exp_category_field_data` WRITE;
/*!40000 ALTER TABLE `exp_category_field_data` DISABLE KEYS */;
INSERT INTO `exp_category_field_data` VALUES (1,1,1,'Overlays','none'),(2,1,1,'rates','none'),(3,1,1,'loan submissions','none'),(4,1,1,'appraisals','none');
/*!40000 ALTER TABLE `exp_category_field_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_category_fields`
--

DROP TABLE IF EXISTS `exp_category_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_category_fields` (
  `field_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_id` int(4) unsigned NOT NULL,
  `field_name` varchar(32) NOT NULL default '',
  `field_label` varchar(50) NOT NULL default '',
  `field_type` varchar(12) NOT NULL default 'text',
  `field_list_items` text NOT NULL,
  `field_maxl` smallint(3) NOT NULL default '128',
  `field_ta_rows` tinyint(2) NOT NULL default '8',
  `field_default_fmt` varchar(40) NOT NULL default 'none',
  `field_show_fmt` char(1) NOT NULL default 'y',
  `field_text_direction` char(3) NOT NULL default 'ltr',
  `field_required` char(1) NOT NULL default 'n',
  `field_order` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`field_id`),
  KEY `site_id` (`site_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_category_fields`
--

LOCK TABLES `exp_category_fields` WRITE;
/*!40000 ALTER TABLE `exp_category_fields` DISABLE KEYS */;
INSERT INTO `exp_category_fields` VALUES (1,1,1,'file-title','file title','text','',128,6,'none','y','ltr','y',2);
/*!40000 ALTER TABLE `exp_category_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_category_groups`
--

DROP TABLE IF EXISTS `exp_category_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_category_groups` (
  `group_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_name` varchar(50) NOT NULL,
  `sort_order` char(1) NOT NULL default 'a',
  `exclude_group` tinyint(1) unsigned NOT NULL default '0',
  `field_html_formatting` char(4) NOT NULL default 'all',
  `can_edit_categories` text,
  `can_delete_categories` text,
  PRIMARY KEY  (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_category_groups`
--

LOCK TABLES `exp_category_groups` WRITE;
/*!40000 ALTER TABLE `exp_category_groups` DISABLE KEYS */;
INSERT INTO `exp_category_groups` VALUES (1,1,'File Categories','a',0,'safe','','');
/*!40000 ALTER TABLE `exp_category_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_category_posts`
--

DROP TABLE IF EXISTS `exp_category_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_category_posts` (
  `entry_id` int(10) unsigned NOT NULL,
  `cat_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`entry_id`,`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_category_posts`
--

LOCK TABLES `exp_category_posts` WRITE;
/*!40000 ALTER TABLE `exp_category_posts` DISABLE KEYS */;
INSERT INTO `exp_category_posts` VALUES (17,2);
/*!40000 ALTER TABLE `exp_category_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_channel_data`
--

DROP TABLE IF EXISTS `exp_channel_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_channel_data` (
  `entry_id` int(10) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL default '1',
  `channel_id` int(4) unsigned NOT NULL,
  `field_id_2` text,
  `field_ft_2` tinytext,
  `field_id_3` text,
  `field_ft_3` tinytext,
  `field_id_4` text,
  `field_ft_4` tinytext,
  `field_id_5` text,
  `field_ft_5` tinytext,
  `field_id_6` float default '0',
  `field_ft_6` tinytext,
  PRIMARY KEY  (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_channel_data`
--

LOCK TABLES `exp_channel_data` WRITE;
/*!40000 ALTER TABLE `exp_channel_data` DISABLE KEYS */;
INSERT INTO `exp_channel_data` VALUES (7,1,2,'​Affiliated Mortgage Company’s Wholesale/Mini Correspondent Division provides our clients the tools to stay on top. We offer a wide variety of competitively priced products with an experienced staff that provides you with an efficient loan process, prompt closings, and personalized customer service. Our unique strategy allows our brokers to use one operations center for every loan type including Conventional Conforming, FHA, VA, USDA, Texas Cash-Out and Texas Veterans Land Board lending programs. Additionally, we are an agency direct lender which makes your experience with Affiliated Mortgage Company more consistent and dependable.\n\nAffiliated Mortgage Company is a wholly owned subsidiary of Benchmark Bank, member FDIC. Since Benchmark Bank was established in 1964, we have taken pride in the philosophy that banking should be based on personal relationships and expertise.\n\n\n\n','xhtml','​Wholesale/Mini Correspondent…Above and Beyond','none','Above and Beyond','none','','none',0,'none'),(9,1,2,'<table class=\"table amc\">\n\n                <tbody>\n                    <tr>\n                        <td>\n                            <address class=\"contact-address\">\n                                10700 Richmond Ave.<br/>\n                                Suite 150, Houston, Texas 77042<br/>\n                                <abbr title=\"Phone\">Ph:</abbr> 713 842-7720 or 866 496-7911<br/>\n                                Fax: 713 843-7722\n                                <br/><br/>\n                                <em><a href=\"http://www.affiliatedtpo.com\" target=\"_blank\">www.affiliatedtpo.com</a></em><br/>\n                                Monday-Friday 8:30 am - 5:30 pm\n                            </address>\n\n                        </td>\n                        <td><a href=\"http://goo.gl/maps/7pPEO\" target=\"_blank\"><div class=\"amc-map\"></div></a></td>\n                    </tr>\n\n                    <tr>                        \n                        <td colspan=\"2\" class=\"mini-thead\">Executive Officers</td>\n                    </tr>\n\n\n\n                    <tr>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Jerry Alred</em> - President</li>\n                                <li>Ext. 102</li>\n                                <li>Cell - 713 305-4620</li>\n                                <li><a href=\"mailto:jalred@affiliatedtpo.com\">jalred@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Mylena Alred</em> - EVP</li>\n                                <li>Ext. 101</li>\n                                <li>Cell - 713 504-1988</li>\n                                <li><a href=\"mailto:malred@affiliatedtpo.com\">malred@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                    </tr>\n\n                    <tr>                        \n                        <td colspan=\"2\" class=\"mini-thead\">Operations</td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Becky Boddie</em> - VP/Operations Mgr</li>\n                                <li>Ext. 103</li>\n                                <li><a href=\"mailto:bbodie@affiliatedtpo.com\">bbodie@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Donna Kacal</em> - Senior UW</li>\n                                <li>Ext. 104</li>\n                                <li><a href=\"mailto:dkacal@affiliatedtpo.com\">dkacal@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                    </tr>\n                    <tr>\n                        <td colspan=\"2\">\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Lisa Kaharl</em> - Closing</li>\n                                <li>Ext. 105</li>\n                                <li><a href=\"mailto:lkaharl@affiliatedtpo.com\">lkaharl@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                    </tr>\n                    <tr>                        \n                        <td colspan=\"2\" class=\"mini-thead\">Sales</td>\n                    </tr>\n                    <tr>\n                    <tr>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Karen Boots</em> - Acct Mgr</li>\n                                <li>Cell - 972 310-1123</li>\n                                <li><a href=\"mailto:kboots@affiliatedtpo.com\">kboots@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>Kathryn Hodge</em> - Acct Mgr</li>\n                                <li>Ext. 107</li>\n                                <li><a href=\"mailto:khodge@affiliatedtpo.com\">khodge@affiliatedtpo.com</a></li>\n                            </ul>\n                        </td>\n                    </tr>\n                    <tr>\n                        <td class=\"mini-thead\">ID Numbers</td>\n                        <td class=\"mini-thead\">Mortgage Clause</td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <ul>\n                                <li class=\"amc-contact-name\"><em>FHA: </em></li>\n                                <li class=\"amc-contact-name\"><em>VA: </em></li>\n\n                            </ul>\n                        </td>\n                        <td>\n                            <ul>\n                                <li>Affiliated Mortgage Company, ISOA-ATIMA</li>\n                                <li>Loan Number ____________</li>\n                                <li>P.O. Box 2225</li>\n                                <li>Monroe, LA. 71207-2225</li>\n                            </ul>\n                        </td>\n                    </tr>\n                    <tr>                        \n                        <td colspan=\"2\" class=\"mini-thead\">Helpful E-mail Addresses</td>\n                    </tr>\n                    <tr>\n                        <td>                                                                        \n                            <ul>\n                                <li><a href=\"mailto:scenario.helpline@affiliatedtpo.com\">scenario.helpline@affiliatedtpo.com</a></li>\n                                <li><a href=\"mailto:submissions@affiliatedtpo.com\">submissions@affiliatedtpo.com</a></li>\n                                <li><a href=\"mailto:conditions@affiliatedtpo.com\">conditions@affiliatedtpo.com</a></li>\n\n                            </ul>\n                        </td>\n                        <td>                                                                        \n                            <ul>\n                                <li><a href=\"mailto:appraisals@affiliatedtpo.com\">appraisals@affiliatedtpo.com</a></li>\n                                <li><a href=\"mailto:locks@affiliatedtpo.com\">locks@affiliatedtpo.com</a></li>\n                                <li><a href=\"mailto:closings@affiliatedtpo.com\">closings@affiliatedtpo.com</a></li>\n\n                            </ul>\n                        </td>\n                    </tr>\n                </tbody>\n            </table>','none','Company & Contact Information','none','Above and Beyond','none','','none',0,'none'),(10,1,2,'            <table class=\"table amc-products\">\n                <thead></thead>\n                <tbody>\n                    <tr>\n                        <td>\n                            <h3 class=\"amc\">Conventional</h3> \n                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation            \n                        </td>\n                        <td>\n                            <h3 class=\"amc\">DU Refi Plus</h3> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation\n                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <h3 class=\"amc\">FHA</h3> \n                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation            \n                        </td>\n                        <td>\n                            <h3 class=\"amc\">VA</h3> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation\n                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <h3 class=\"amc\">Texas Home Equity</h3> \n                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation            \n                        </td>\n                        <td>\n                            <h3 class=\"amc\">USDA</h3> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation\n                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <h3 class=\"amc\">Texas Veterans Land Board</h3> \n                            <em><a href=\"http://www.glo.texas.gov/vlb\" target=\"_blank\">Visit website ></a></em>    \n                        </td>\n                        <td class=\"empty\">\n                            \n                        </td>\n                    </tr>\n                </tbody>\n            </table>','none','Product Offerings','none','Above and Beyond','none','','none',0,'none'),(11,1,2,'<!--<div class=\"program-list\">\n\n    <ul>\n\n        <li>- Bank Owned Company</li>\n        <li>- Competitive Rates</li>\n        <li>- Efficient Loan Process</li>\n        <li>- Underwriting to Risk</li>\n        <li>- Experienced In-House Processing, Underwriting and Closing</li>\n        <li>- Full Complement of Loan Products<em>*</em><br><small>See Corresponding Insert</small></li>\n        <li>- Agency Direct Lender Personalized Customer Service Scenario Help Desks</li>\n        <li>- Prompt Closings</li>\n    </ul>\n</div>-->\n<div class=\"program-table\">\n    <h3 class=\"amc\">Warehouse Program</h3>\n    <hr/>\n    <table class=\"table table-bordered\">  \n        <thead>  \n            <tr>  \n                <th colspan=\"2\">Silver Program</th>  \n\n            </tr>  \n        </thead>  \n        <tbody>  \n            <tr>  \n                <td>Line Amounts</td>  \n                <td class=\"right\">\n                    Starting at $1,000,000\n                </td>   \n            </tr>  \n            <tr>  \n                <td>Financial Requirements</td>  \n                <td class=\"right\">\n                    <ul>\n                        <li>- $75,000 Minimum Audited Tangible Net Worth</li>\n                        <li>- Two Years Business Audited Financials</li>\n                        <li>- Two Years Business Tax Returns</li>\n                        <li>- Two Years Personal Tax Returns for All Guarantors</li>\n                    </ul>\n                </td>  \n\n            </tr>  \n\n\n\n\n\n\n\n\n\n            <tr>  \n                <td>Pledge Amounts</td>  \n                <td class=\"right\">\n                    1% of Approved Facility Amount\n                </td>   \n            </tr>                          <tr>  \n                <td>Personal Financial Statements</td>  \n                <td class=\"right\">\n                    Required for Each Guarantor with at Least 20% Ownership in Company\n                </td>   \n            </tr>                          <tr>  \n                <td>E&O and Fidelity Bond</td>  \n                <td class=\"right\">\n                    Minimum Coverage of $300,000 Each\n                </td>   \n            </tr>                          <tr>  \n                <td>Leverage Ratio</td>  \n                <td class=\"right\">\n                    Maximum of 20:1\n                </td>   \n            </tr>                          <tr>  \n                <td>Eligible Loans</td>  \n                <td class=\"right\">\n                    Affiliated Mortgage Company Conventional Conforming and VA\n                </td>   \n            </tr>                          <tr>  \n                <td>Funding Percentage</td>  \n                <td class=\"right\">\n                    100% of Note Amount\n                </td>   \n            </tr>                          <tr>  \n                <td>Pass-Through Rate</td>  \n                <td class=\"right\">\n                    Index: 30 Day Libor +1.75% /Floor of 4.25%\n                </td>   \n            </tr>  \n            <tr>  \n                <td>Transaction Fee</td>  \n                <td class=\"right\">\n                    $100\n                </td>   \n            </tr>  \n            <tr>  \n                <td class=\"amc-program-last\" colspan=\"2\">\n					Please <em><a href=\"/uploads/bin/BMB_Loan_Purchase_Program_Application_Mini.pdf\">click here</a></em> to access our Mortgage Warehouse Application.<br/> You may download,\nprint, complete, scan and return to <em><a href=\"mailto:gmccourt@benchmarkbank.com\">gmccourt@benchmarkbank.com</a></em>.<br/> If you have any\nquestions please contact Gary McCourt at <em>972-673-4093</em>.\n                    \n                </td>  \n            </tr>\n        </tbody>  \n    </table> \n</div>','none','','none','Above and Beyond','none','','none',0,'none'),(20,1,2,'<p>Content coming soon.</p>','none','FAQ','none','Above and Beyond','none','','none',0,'none'),(12,1,2,'<h3 class=\"amc\">Affiliated Mortgage</h3>\n            <hr/>\n            <table class=\"table amc-states\">\n                <thead></thead>\n                <tbody>\n                    <tr>\n                        <td>AK Alaska</td>\n                        <td>ID Idaho</td>\n                    </tr>\n                    <tr>\n                        <td>MS Mississippi</td>\n                        <td>PA Pennsylvania</td>\n                    </tr>\n                    <tr>\n                        <td>WI Wisconsin</td>\n                        <td>IN Indiana</td>\n                    </tr>\n                    <tr>\n                        <td>AR Arkansas</td>\n                        <td>SC South Carolina</td>\n                    </tr>\n                    <tr>\n                        <td>MT Montana</td>\n                        <td>KS Kansas</td>\n                    </tr>\n                    <tr>\n                        <td>WY Wyoming</td>\n                        <td>SD South Dakota</td>\n                    </tr>\n                    <tr>\n                        <td>CO Colorado</td>\n                        <td>KY Kentucky</td>\n                    </tr>\n                    <tr>\n                        <td>NE Nebraska</td>\n                        <td>TN Tennessee</td>\n                    </tr>\n                    <tr>\n                        <td>FL Florida</td>\n                        <td>LA Louisiana</td>\n                    </tr>\n                    <tr>\n                        <td>OH Ohio</td>\n                        <td>TX Texas</td>\n                    </tr>\n                    <tr>\n                        <td>GA Georgia</td>\n                        <td>ME Maine</td>\n                    </tr>\n                    <tr>\n                        <td>OK Oklahoma</td>\n                        <td>UT Utah</td>\n                    </tr>\n                    <tr>\n                        <td>IA Iowa</td>\n                        <td>MO Missouri</td>\n                    </tr>\n                    <tr>\n                        <td>OR Oregon</td>\n                        <td>VA Virginia</td>\n                    </tr>\n                </tbody>\n            </table>','none','List of Allowable States by Origination','none','Above and Beyond','none','','none',0,'none'),(13,1,2,'<p>Content coming soon.</p>','none','Overlays','none','Above and Beyond','none','','none',7,'none'),(14,1,2,'<table class=\"table amc-products\">\n    <thead></thead>\n    <tbody>\n        <tr>\n            <td>\n                <h3 class=\"amc\">Delivery:</h3> \n                <address>\n                    Affiliated Mortgage Company<br/>\n                    10700 Richmond,<br/>\n                    Suite 150,<br/>\n                    Houston, TX 77042\n                </address>                \n\n            </td>\n            <td>\n                <h3 class=\"amc\">E-Mail:</h3>\n                E-Mail loan to:<br/>\n                <em><a href=\"mailto:submissions@affilitatedtpo.com\">submissions@affilitatedtpo.com</a></em><br/><br/>\n                Please send appraisal separately to:<br/>\n                <em><a href=\"mailto:appraisals@affilitatedtpo.com\">appraisals@affilitatedtpo.com</a></em>\n            </td>\n        </tr>\n        <tr>\n            <td>\n                <h3 class=\"amc\">Fax:</h3> \n                <div class=\"amc-fax-number\">713 843-7722</div>       \n            </td>\n            <td>\n                <h3 class=\"amc\">Broker LOS:</h3>\n                From your LOS system:<br/>\n                1. Go to file -> Export -> FNMA 3.2<br/>\n                2. Save and email as an attachment to<br/>\n                <em><a href=\"mailto:submissions@classichomefinancial.com\">submissions@affiliatedtpo.com</a></em>\n            </td>\n        </tr>\n    </tbody>\n</table><br/><br/>','none','Loan Submissions','none','Above and Beyond','none','','none',4,'none'),(15,1,2,'<p>Please find the Broker Application Package and Information attached. Please download,\nprint, complete and return to <em><a href=\"mailto:submissions@affiliatedtpo.com\">submissions@affiliatedtpo.com</a></em>. Should you have any\nquestions, please contact your account representative or call the corporate office at <em>866-496-7911</em>.</p>\n','none','New Broker Signup','none','Above and Beyond','none','','none',8,'none'),(16,1,2,'<p>Content coming soon.</p>','none','Guides','none','Above and Beyond','none','','none',6,'none'),(17,1,2,'<p>Content coming soon.</p>','none','Rates','none','Above and Beyond','none','','none',5,'none'),(18,1,2,'','none','Forms','none','Above and Beyond','none','','none',9,'none'),(19,1,2,'<p>Submit your loans with the form below to Affiliated Mortgage Company: <br/>\n10700 Richmond, Suite 150, Houston, TX 77042 <br/>or by email to <em><a href=\"mailto:submissions@affilitatedtpo.com\">submissions@affilitatedtpo.com</a></em> <br/>or by fax to 713 843-7722.</p>','none','Appraisals','none','Above and Beyond','none','','none',3,'none'),(21,1,2,'<p>Content coming soon.</p>','none','Bulletins','none','Above and Beyond','none','','none',0,'none');
/*!40000 ALTER TABLE `exp_channel_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_channel_entries_autosave`
--

DROP TABLE IF EXISTS `exp_channel_entries_autosave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_channel_entries_autosave` (
  `entry_id` int(10) unsigned NOT NULL auto_increment,
  `original_entry_id` int(10) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL default '1',
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL default '0',
  `forum_topic_id` int(10) unsigned default NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `title` varchar(100) NOT NULL,
  `url_title` varchar(75) NOT NULL,
  `status` varchar(50) NOT NULL,
  `versioning_enabled` char(1) NOT NULL default 'n',
  `view_count_one` int(10) unsigned NOT NULL default '0',
  `view_count_two` int(10) unsigned NOT NULL default '0',
  `view_count_three` int(10) unsigned NOT NULL default '0',
  `view_count_four` int(10) unsigned NOT NULL default '0',
  `allow_comments` varchar(1) NOT NULL default 'y',
  `sticky` varchar(1) NOT NULL default 'n',
  `entry_date` int(10) NOT NULL,
  `year` char(4) NOT NULL,
  `month` char(2) NOT NULL,
  `day` char(3) NOT NULL,
  `expiration_date` int(10) NOT NULL default '0',
  `comment_expiration_date` int(10) NOT NULL default '0',
  `edit_date` bigint(14) default NULL,
  `recent_comment_date` int(10) default NULL,
  `comment_total` int(4) unsigned NOT NULL default '0',
  `entry_data` text,
  PRIMARY KEY  (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `url_title` (`url_title`),
  KEY `status` (`status`),
  KEY `entry_date` (`entry_date`),
  KEY `expiration_date` (`expiration_date`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_channel_entries_autosave`
--

LOCK TABLES `exp_channel_entries_autosave` WRITE;
/*!40000 ALTER TABLE `exp_channel_entries_autosave` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_channel_entries_autosave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_channel_fields`
--

DROP TABLE IF EXISTS `exp_channel_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_channel_fields` (
  `field_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_id` int(4) unsigned NOT NULL,
  `field_name` varchar(32) NOT NULL,
  `field_label` varchar(50) NOT NULL,
  `field_instructions` text,
  `field_type` varchar(50) NOT NULL default 'text',
  `field_list_items` text NOT NULL,
  `field_pre_populate` char(1) NOT NULL default 'n',
  `field_pre_channel_id` int(6) unsigned default NULL,
  `field_pre_field_id` int(6) unsigned default NULL,
  `field_ta_rows` tinyint(2) default '8',
  `field_maxl` smallint(3) default NULL,
  `field_required` char(1) NOT NULL default 'n',
  `field_text_direction` char(3) NOT NULL default 'ltr',
  `field_search` char(1) NOT NULL default 'n',
  `field_is_hidden` char(1) NOT NULL default 'n',
  `field_fmt` varchar(40) NOT NULL default 'xhtml',
  `field_show_fmt` char(1) NOT NULL default 'y',
  `field_order` int(3) unsigned NOT NULL,
  `field_content_type` varchar(20) NOT NULL default 'any',
  `field_settings` text,
  PRIMARY KEY  (`field_id`),
  KEY `group_id` (`group_id`),
  KEY `field_type` (`field_type`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_channel_fields`
--

LOCK TABLES `exp_channel_fields` WRITE;
/*!40000 ALTER TABLE `exp_channel_fields` DISABLE KEYS */;
INSERT INTO `exp_channel_fields` VALUES (3,1,5,'page_h2','Page H2','Words wrapped in <code><em></code> will be red.','text','','0',0,0,2,128,'n','ltr','y','n','none','n',2,'any','YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3R5cGUiO3M6MzoiYWxsIjtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30='),(2,1,5,'page_body','Page Body','Words wrapped in <code><em></code> will be red.','textarea','','0',0,0,20,128,'n','ltr','y','n','xhtml','y',10,'any','YTo2OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6InkiO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30='),(4,1,5,'page_h1','Page H1','','text','','0',0,0,6,128,'n','ltr','n','n','none','y',1,'any','YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3R5cGUiO3M6MzoiYWxsIjtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30='),(5,1,5,'subheader','Subheader','Small optional subheader below h2 field.','text','','0',0,0,6,128,'n','ltr','n','n','none','n',3,'any','YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3R5cGUiO3M6MzoiYWxsIjtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30='),(6,1,5,'directory_id','File Directory ID','If displaying links to files, enter the directory ID to pull the data from.  You can find the ID\'s at CP Home > File Manager > File Upload Preferences\n','text','','0',0,0,6,2,'n','ltr','n','n','none','n',5,'any','YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3R5cGUiO3M6NzoibnVtZXJpYyI7czoxODoiZmllbGRfc2hvd19zbWlsZXlzIjtzOjE6Im4iO3M6MTk6ImZpZWxkX3Nob3dfZ2xvc3NhcnkiO3M6MToibiI7czoyMToiZmllbGRfc2hvd19zcGVsbGNoZWNrIjtzOjE6Im4iO3M6MjY6ImZpZWxkX3Nob3dfZm9ybWF0dGluZ19idG5zIjtzOjE6Im4iO3M6MjQ6ImZpZWxkX3Nob3dfZmlsZV9zZWxlY3RvciI7czoxOiJuIjtzOjIwOiJmaWVsZF9zaG93X3dyaXRlbW9kZSI7czoxOiJuIjt9');
/*!40000 ALTER TABLE `exp_channel_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_channel_member_groups`
--

DROP TABLE IF EXISTS `exp_channel_member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_channel_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `channel_id` int(6) unsigned NOT NULL,
  PRIMARY KEY  (`group_id`,`channel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_channel_member_groups`
--

LOCK TABLES `exp_channel_member_groups` WRITE;
/*!40000 ALTER TABLE `exp_channel_member_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_channel_member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_channel_titles`
--

DROP TABLE IF EXISTS `exp_channel_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_channel_titles` (
  `entry_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL default '0',
  `forum_topic_id` int(10) unsigned default NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `title` varchar(100) NOT NULL,
  `url_title` varchar(75) NOT NULL,
  `status` varchar(50) NOT NULL,
  `versioning_enabled` char(1) NOT NULL default 'n',
  `view_count_one` int(10) unsigned NOT NULL default '0',
  `view_count_two` int(10) unsigned NOT NULL default '0',
  `view_count_three` int(10) unsigned NOT NULL default '0',
  `view_count_four` int(10) unsigned NOT NULL default '0',
  `allow_comments` varchar(1) NOT NULL default 'y',
  `sticky` varchar(1) NOT NULL default 'n',
  `entry_date` int(10) NOT NULL,
  `year` char(4) NOT NULL,
  `month` char(2) NOT NULL,
  `day` char(3) NOT NULL,
  `expiration_date` int(10) NOT NULL default '0',
  `comment_expiration_date` int(10) NOT NULL default '0',
  `edit_date` bigint(14) default NULL,
  `recent_comment_date` int(10) default NULL,
  `comment_total` int(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `url_title` (`url_title`),
  KEY `status` (`status`),
  KEY `entry_date` (`entry_date`),
  KEY `expiration_date` (`expiration_date`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_channel_titles`
--

LOCK TABLES `exp_channel_titles` WRITE;
/*!40000 ALTER TABLE `exp_channel_titles` DISABLE KEYS */;
INSERT INTO `exp_channel_titles` VALUES (9,1,2,1,NULL,'107.202.218.108','Contact','contact','open','y',0,0,0,0,'y','n',1371226020,'2013','06','14',0,0,20130617213546,0,0),(10,1,2,1,NULL,'24.155.109.33','Products','products','open','y',0,0,0,0,'n','n',1371226560,'2013','06','14',0,0,20130616183233,0,0),(7,1,2,1,NULL,'127.0.0.1','Wholesale','wholesale','open','y',0,0,0,0,'y','n',1371172500,'2013','06','13',0,0,20130614162200,0,0),(12,1,2,1,NULL,'127.0.0.1','Licensed States','licensed-states','open','y',0,0,0,0,'n','n',1371226920,'2013','06','14',0,0,20130615175233,0,0),(11,1,2,1,NULL,'107.202.218.108','Programs','programs','open','y',0,0,0,0,'y','n',1371226620,'2013','06','14',0,0,20130617213411,0,0),(13,1,2,1,NULL,'107.202.218.108','Overlays','overlays','open','y',0,0,0,0,'y','n',1371337440,'2013','06','15',0,0,20130617214835,0,0),(14,1,2,1,NULL,'107.202.218.108','Loan Submissions','loan-submissions','open','y',0,0,0,0,'y','n',1371339240,'2013','06','15',0,0,20130617215429,0,0),(15,1,2,1,NULL,'24.155.109.33','New Broker Signup','signup','open','y',0,0,0,0,'n','n',1371342600,'2013','06','15',0,0,20130617181436,0,0),(16,1,2,1,NULL,'107.202.218.108','Guides','guides','open','y',0,0,0,0,'y','n',1371342660,'2013','06','15',0,0,20130617215101,0,0),(17,1,2,1,NULL,'107.202.218.108','Rates','rates','open','y',0,0,0,0,'n','n',1371344460,'2013','06','15',0,0,20130617215120,0,0),(18,1,2,1,NULL,'127.0.0.1','Forms','forms','open','y',0,0,0,0,'y','n',1371344940,'2013','06','15',0,0,20130616020751,0,0),(19,1,2,1,NULL,'24.155.109.33','Appraisals','appraisals','open','y',0,0,0,0,'y','n',1371353220,'2013','06','15',0,0,20130617221406,0,0),(20,1,2,1,NULL,'107.202.218.108','FAQ','faq','open','y',0,0,0,0,'n','n',1371405180,'2013','06','16',0,0,20130617215048,0,0),(21,1,2,1,NULL,'107.202.218.108','Bulletins','bulletins','open','y',0,0,0,0,'y','n',1371406560,'2013','06','16',0,0,20130617215032,0,0);
/*!40000 ALTER TABLE `exp_channel_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_channels`
--

DROP TABLE IF EXISTS `exp_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_channels` (
  `channel_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `channel_name` varchar(40) NOT NULL,
  `channel_title` varchar(100) NOT NULL,
  `channel_url` varchar(100) NOT NULL,
  `channel_description` varchar(255) default NULL,
  `channel_lang` varchar(12) NOT NULL,
  `total_entries` mediumint(8) NOT NULL default '0',
  `total_comments` mediumint(8) NOT NULL default '0',
  `last_entry_date` int(10) unsigned NOT NULL default '0',
  `last_comment_date` int(10) unsigned NOT NULL default '0',
  `cat_group` varchar(255) default NULL,
  `status_group` int(4) unsigned default NULL,
  `deft_status` varchar(50) NOT NULL default 'open',
  `field_group` int(4) unsigned default NULL,
  `search_excerpt` int(4) unsigned default NULL,
  `deft_category` varchar(60) default NULL,
  `deft_comments` char(1) NOT NULL default 'y',
  `channel_require_membership` char(1) NOT NULL default 'y',
  `channel_max_chars` int(5) unsigned default NULL,
  `channel_html_formatting` char(4) NOT NULL default 'all',
  `channel_allow_img_urls` char(1) NOT NULL default 'y',
  `channel_auto_link_urls` char(1) NOT NULL default 'n',
  `channel_notify` char(1) NOT NULL default 'n',
  `channel_notify_emails` varchar(255) default NULL,
  `comment_url` varchar(80) default NULL,
  `comment_system_enabled` char(1) NOT NULL default 'y',
  `comment_require_membership` char(1) NOT NULL default 'n',
  `comment_use_captcha` char(1) NOT NULL default 'n',
  `comment_moderate` char(1) NOT NULL default 'n',
  `comment_max_chars` int(5) unsigned default '5000',
  `comment_timelock` int(5) unsigned NOT NULL default '0',
  `comment_require_email` char(1) NOT NULL default 'y',
  `comment_text_formatting` char(5) NOT NULL default 'xhtml',
  `comment_html_formatting` char(4) NOT NULL default 'safe',
  `comment_allow_img_urls` char(1) NOT NULL default 'n',
  `comment_auto_link_urls` char(1) NOT NULL default 'y',
  `comment_notify` char(1) NOT NULL default 'n',
  `comment_notify_authors` char(1) NOT NULL default 'n',
  `comment_notify_emails` varchar(255) default NULL,
  `comment_expiration` int(4) unsigned NOT NULL default '0',
  `search_results_url` varchar(80) default NULL,
  `ping_return_url` varchar(80) default NULL,
  `show_button_cluster` char(1) NOT NULL default 'y',
  `rss_url` varchar(80) default NULL,
  `enable_versioning` char(1) NOT NULL default 'n',
  `max_revisions` smallint(4) unsigned NOT NULL default '10',
  `default_entry_title` varchar(100) default NULL,
  `url_title_prefix` varchar(80) default NULL,
  `live_look_template` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`channel_id`),
  KEY `cat_group` (`cat_group`),
  KEY `status_group` (`status_group`),
  KEY `field_group` (`field_group`),
  KEY `channel_name` (`channel_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_channels`
--

LOCK TABLES `exp_channels` WRITE;
/*!40000 ALTER TABLE `exp_channels` DISABLE KEYS */;
INSERT INTO `exp_channels` VALUES (2,1,'content','Main Content','http://nomral.com/index.php','','en',14,0,1371406560,0,'1',1,'open',5,3,'','y','y',NULL,'all','y','n','n','','','y','n','n','n',5000,0,'y','xhtml','safe','n','y','n','n','',0,'','','y','','n',10,'','',0);
/*!40000 ALTER TABLE `exp_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_comment_subscriptions`
--

DROP TABLE IF EXISTS `exp_comment_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_comment_subscriptions` (
  `subscription_id` int(10) unsigned NOT NULL auto_increment,
  `entry_id` int(10) unsigned default NULL,
  `member_id` int(10) default '0',
  `email` varchar(50) default NULL,
  `subscription_date` varchar(10) default NULL,
  `notification_sent` char(1) default 'n',
  `hash` varchar(15) default NULL,
  PRIMARY KEY  (`subscription_id`),
  KEY `entry_id` (`entry_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_comment_subscriptions`
--

LOCK TABLES `exp_comment_subscriptions` WRITE;
/*!40000 ALTER TABLE `exp_comment_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_comment_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_comments`
--

DROP TABLE IF EXISTS `exp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_comments` (
  `comment_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) default '1',
  `entry_id` int(10) unsigned default '0',
  `channel_id` int(4) unsigned default '1',
  `author_id` int(10) unsigned default '0',
  `status` char(1) default '0',
  `name` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `url` varchar(75) default NULL,
  `location` varchar(50) default NULL,
  `ip_address` varchar(45) default NULL,
  `comment_date` int(10) default NULL,
  `edit_date` int(10) default NULL,
  `comment` text,
  PRIMARY KEY  (`comment_id`),
  KEY `entry_id` (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `status` (`status`),
  KEY `site_id` (`site_id`),
  KEY `comment_date_idx` (`comment_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_comments`
--

LOCK TABLES `exp_comments` WRITE;
/*!40000 ALTER TABLE `exp_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_cp_log`
--

DROP TABLE IF EXISTS `exp_cp_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_cp_log` (
  `id` int(10) NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `member_id` int(10) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `act_date` int(10) NOT NULL,
  `action` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_cp_log`
--

LOCK TABLES `exp_cp_log` WRITE;
/*!40000 ALTER TABLE `exp_cp_log` DISABLE KEYS */;
INSERT INTO `exp_cp_log` VALUES (1,1,1,'admin','127.0.0.1',1371057298,'Logged in'),(2,1,1,'admin','127.0.0.1',1371057532,'Channel Created:&nbsp;&nbsp;test'),(3,1,1,'admin','127.0.0.1',1371057993,'Field Group Created:&nbsp;foo'),(4,1,1,'admin','127.0.0.1',1371057999,'Field Group Created:&nbsp;bar'),(5,1,1,'admin','127.0.0.1',1371059306,'Channel Deleted:&nbsp;&nbsp;test'),(6,1,1,'admin','127.0.0.1',1371059323,'Channel Created:&nbsp;&nbsp;site'),(7,1,1,'admin','127.0.0.1',1371059339,'Channel Created:&nbsp;&nbsp;jarjar'),(8,1,1,'admin','127.0.0.1',1371151083,'Logged in'),(9,1,1,'admin','127.0.0.1',1371161972,'Logged in'),(10,1,1,'admin','127.0.0.1',1371166711,'Channel Deleted:&nbsp;&nbsp;jarjar'),(11,1,1,'admin','127.0.0.1',1371166857,'Field group Deleted:&nbsp;&nbsp;bar'),(12,1,1,'admin','127.0.0.1',1371166860,'Field group Deleted:&nbsp;&nbsp;foo'),(13,1,1,'admin','127.0.0.1',1371166882,'Field Group Created:&nbsp;Page Title'),(14,1,1,'admin','127.0.0.1',1371166891,'Field Group Created:&nbsp;Page Body'),(15,1,1,'admin','127.0.0.1',1371168039,'Field group Deleted:&nbsp;&nbsp;Page Body'),(16,1,1,'admin','127.0.0.1',1371168042,'Field group Deleted:&nbsp;&nbsp;Page Title'),(17,1,1,'admin','127.0.0.1',1371168055,'Field Group Created:&nbsp;Page Components'),(18,1,1,'admin','127.0.0.1',1371172516,'Custom Field Deleted:&nbsp;Page Title'),(19,1,1,'admin','127.0.0.1',1371175146,'Logged in'),(20,1,1,'admin','127.0.0.1',1371223194,'Logged in'),(21,1,1,'admin','127.0.0.1',1371229170,'Logged in'),(22,1,1,'admin','127.0.0.1',1371317562,'Logged in'),(23,1,1,'admin','127.0.0.1',1371317960,'Logged in'),(24,1,1,'admin','127.0.0.1',1371318740,'Logged in'),(25,1,1,'admin','127.0.0.1',1371326636,'Logged in'),(26,1,1,'admin','127.0.0.1',1371330903,'Logged in'),(27,1,1,'admin','127.0.0.1',1371337677,'Category Group Created:&nbsp;&nbsp;File Categories'),(28,1,1,'admin','127.0.0.1',1371340396,'Upload Preference Deleted:&nbsp;&nbsp;Docs'),(29,1,1,'admin','127.0.0.1',1371340402,'Upload Preference Deleted:&nbsp;&nbsp;pdfs'),(30,1,1,'admin','127.0.0.1',1371349556,'Logged out'),(31,1,1,'admin','127.0.0.1',1371349645,'Logged in'),(32,1,1,'admin','127.0.0.1',1371350958,'Field Group Created:&nbsp;File Fields'),(33,1,1,'admin','127.0.0.1',1371351150,'Channel Created:&nbsp;&nbsp;Files'),(34,1,1,'admin','127.0.0.1',1371351163,'Channel Deleted:&nbsp;&nbsp;Files'),(35,1,1,'admin','127.0.0.1',1371351180,'Field group Deleted:&nbsp;&nbsp;File Fields'),(36,1,1,'admin','127.0.0.1',1371396247,'Logged in'),(37,1,1,'admin','127.0.0.1',1371396697,'Channel Created:&nbsp;&nbsp;Files Channel'),(38,1,1,'admin','127.0.0.1',1371396716,'Channel Deleted:&nbsp;&nbsp;Files Channel'),(39,1,1,'admin','127.0.0.1',1371403824,'Logged in'),(40,1,1,'admin','127.0.0.1',1371405226,'Logged in'),(41,1,1,'admin','127.0.0.1',1371405380,'Logged in'),(42,1,1,'admin','24.155.109.33',1371406742,'Logged in'),(43,1,1,'admin','24.155.109.33',1371406879,'Logged in'),(44,1,1,'admin','24.155.109.33',1371407512,'Logged in'),(45,1,1,'admin','107.202.218.108',1371407659,'Logged in'),(46,1,1,'admin','24.155.109.33',1371486976,'Logged in'),(47,1,1,'admin','107.202.218.108',1371487278,'Logged in'),(48,1,1,'admin','24.155.109.33',1371487964,'Logged in'),(49,1,1,'admin','107.202.218.108',1371492405,'Logged in'),(50,1,1,'admin','24.155.109.33',1371492733,'Logged in'),(51,1,1,'admin','24.155.109.33',1371493441,'Logged in'),(52,1,1,'admin','107.202.218.108',1371493608,'Logged in'),(53,1,1,'admin','107.202.218.108',1371493796,'Logged in'),(54,1,1,'admin','24.155.109.33',1371494530,'Logged in'),(55,1,1,'admin','107.202.218.108',1371504667,'Logged in'),(56,1,1,'admin','24.155.109.33',1371507219,'Logged in');
/*!40000 ALTER TABLE `exp_cp_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_cp_search_index`
--

DROP TABLE IF EXISTS `exp_cp_search_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_cp_search_index` (
  `search_id` int(10) unsigned NOT NULL auto_increment,
  `controller` varchar(20) default NULL,
  `method` varchar(50) default NULL,
  `language` varchar(20) default NULL,
  `access` varchar(50) default NULL,
  `keywords` text,
  PRIMARY KEY  (`search_id`),
  FULLTEXT KEY `keywords` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_cp_search_index`
--

LOCK TABLES `exp_cp_search_index` WRITE;
/*!40000 ALTER TABLE `exp_cp_search_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_cp_search_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_developer_log`
--

DROP TABLE IF EXISTS `exp_developer_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_developer_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `timestamp` int(10) unsigned NOT NULL,
  `viewed` char(1) NOT NULL default 'n',
  `description` text,
  `function` varchar(100) default NULL,
  `line` int(10) unsigned default NULL,
  `file` varchar(255) default NULL,
  `deprecated_since` varchar(10) default NULL,
  `use_instead` varchar(100) default NULL,
  `template_id` int(10) unsigned NOT NULL default '0',
  `template_name` varchar(100) default NULL,
  `template_group` varchar(100) default NULL,
  `addon_module` varchar(100) default NULL,
  `addon_method` varchar(100) default NULL,
  `snippets` text,
  PRIMARY KEY  (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_developer_log`
--

LOCK TABLES `exp_developer_log` WRITE;
/*!40000 ALTER TABLE `exp_developer_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_developer_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_email_cache`
--

DROP TABLE IF EXISTS `exp_email_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_email_cache` (
  `cache_id` int(6) unsigned NOT NULL auto_increment,
  `cache_date` int(10) unsigned NOT NULL default '0',
  `total_sent` int(6) unsigned NOT NULL,
  `from_name` varchar(70) NOT NULL,
  `from_email` varchar(70) NOT NULL,
  `recipient` text NOT NULL,
  `cc` text NOT NULL,
  `bcc` text NOT NULL,
  `recipient_array` mediumtext NOT NULL,
  `subject` varchar(120) NOT NULL,
  `message` mediumtext NOT NULL,
  `plaintext_alt` mediumtext NOT NULL,
  `mailinglist` char(1) NOT NULL default 'n',
  `mailtype` varchar(6) NOT NULL,
  `text_fmt` varchar(40) NOT NULL,
  `wordwrap` char(1) NOT NULL default 'y',
  `priority` char(1) NOT NULL default '3',
  PRIMARY KEY  (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_email_cache`
--

LOCK TABLES `exp_email_cache` WRITE;
/*!40000 ALTER TABLE `exp_email_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_email_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_email_cache_mg`
--

DROP TABLE IF EXISTS `exp_email_cache_mg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_email_cache_mg` (
  `cache_id` int(6) unsigned NOT NULL,
  `group_id` smallint(4) NOT NULL,
  PRIMARY KEY  (`cache_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_email_cache_mg`
--

LOCK TABLES `exp_email_cache_mg` WRITE;
/*!40000 ALTER TABLE `exp_email_cache_mg` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_email_cache_mg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_email_cache_ml`
--

DROP TABLE IF EXISTS `exp_email_cache_ml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_email_cache_ml` (
  `cache_id` int(6) unsigned NOT NULL,
  `list_id` smallint(4) NOT NULL,
  PRIMARY KEY  (`cache_id`,`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_email_cache_ml`
--

LOCK TABLES `exp_email_cache_ml` WRITE;
/*!40000 ALTER TABLE `exp_email_cache_ml` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_email_cache_ml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_email_console_cache`
--

DROP TABLE IF EXISTS `exp_email_console_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_email_console_cache` (
  `cache_id` int(6) unsigned NOT NULL auto_increment,
  `cache_date` int(10) unsigned NOT NULL default '0',
  `member_id` int(10) unsigned NOT NULL,
  `member_name` varchar(50) NOT NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `recipient` varchar(70) NOT NULL,
  `recipient_name` varchar(50) NOT NULL,
  `subject` varchar(120) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY  (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_email_console_cache`
--

LOCK TABLES `exp_email_console_cache` WRITE;
/*!40000 ALTER TABLE `exp_email_console_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_email_console_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_entry_ping_status`
--

DROP TABLE IF EXISTS `exp_entry_ping_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_entry_ping_status` (
  `entry_id` int(10) unsigned NOT NULL,
  `ping_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`entry_id`,`ping_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_entry_ping_status`
--

LOCK TABLES `exp_entry_ping_status` WRITE;
/*!40000 ALTER TABLE `exp_entry_ping_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_entry_ping_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_entry_versioning`
--

DROP TABLE IF EXISTS `exp_entry_versioning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_entry_versioning` (
  `version_id` int(10) unsigned NOT NULL auto_increment,
  `entry_id` int(10) unsigned NOT NULL,
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL,
  `version_date` int(10) NOT NULL,
  `version_data` mediumtext NOT NULL,
  PRIMARY KEY  (`version_id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_entry_versioning`
--

LOCK TABLES `exp_entry_versioning` WRITE;
/*!40000 ALTER TABLE `exp_entry_versioning` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_entry_versioning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_extensions`
--

DROP TABLE IF EXISTS `exp_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_extensions` (
  `extension_id` int(10) unsigned NOT NULL auto_increment,
  `class` varchar(50) NOT NULL default '',
  `method` varchar(50) NOT NULL default '',
  `hook` varchar(50) NOT NULL default '',
  `settings` text NOT NULL,
  `priority` int(2) NOT NULL default '10',
  `version` varchar(10) NOT NULL default '',
  `enabled` char(1) NOT NULL default 'y',
  PRIMARY KEY  (`extension_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_extensions`
--

LOCK TABLES `exp_extensions` WRITE;
/*!40000 ALTER TABLE `exp_extensions` DISABLE KEYS */;
INSERT INTO `exp_extensions` VALUES (1,'Safecracker_ext','form_declaration_modify_data','form_declaration_modify_data','',10,'2.1','y'),(2,'Rte_ext','myaccount_nav_setup','myaccount_nav_setup','',10,'1.0','y'),(3,'Rte_ext','cp_menu_array','cp_menu_array','',10,'1.0','y'),(4,'Rte_ext','publish_form_entry_data','publish_form_entry_data','',10,'1.0','y');
/*!40000 ALTER TABLE `exp_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_field_formatting`
--

DROP TABLE IF EXISTS `exp_field_formatting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_field_formatting` (
  `formatting_id` int(10) unsigned NOT NULL auto_increment,
  `field_id` int(10) unsigned NOT NULL,
  `field_fmt` varchar(40) NOT NULL,
  PRIMARY KEY  (`formatting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_field_formatting`
--

LOCK TABLES `exp_field_formatting` WRITE;
/*!40000 ALTER TABLE `exp_field_formatting` DISABLE KEYS */;
INSERT INTO `exp_field_formatting` VALUES (9,3,'xhtml'),(8,3,'br'),(7,3,'none'),(4,2,'none'),(5,2,'br'),(6,2,'xhtml'),(10,4,'none'),(11,4,'br'),(12,4,'xhtml'),(13,5,'none'),(14,5,'br'),(15,5,'xhtml'),(16,6,'none'),(17,6,'br'),(18,6,'xhtml');
/*!40000 ALTER TABLE `exp_field_formatting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_field_groups`
--

DROP TABLE IF EXISTS `exp_field_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_field_groups` (
  `group_id` int(4) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_field_groups`
--

LOCK TABLES `exp_field_groups` WRITE;
/*!40000 ALTER TABLE `exp_field_groups` DISABLE KEYS */;
INSERT INTO `exp_field_groups` VALUES (5,1,'Page Components');
/*!40000 ALTER TABLE `exp_field_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_fieldtypes`
--

DROP TABLE IF EXISTS `exp_fieldtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_fieldtypes` (
  `fieldtype_id` int(4) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `version` varchar(12) NOT NULL,
  `settings` text,
  `has_global_settings` char(1) default 'n',
  PRIMARY KEY  (`fieldtype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_fieldtypes`
--

LOCK TABLES `exp_fieldtypes` WRITE;
/*!40000 ALTER TABLE `exp_fieldtypes` DISABLE KEYS */;
INSERT INTO `exp_fieldtypes` VALUES (1,'select','1.0','YTowOnt9','n'),(2,'text','1.0','YTowOnt9','n'),(3,'textarea','1.0','YTowOnt9','n'),(4,'date','1.0','YTowOnt9','n'),(5,'file','1.0','YTowOnt9','n'),(6,'multi_select','1.0','YTowOnt9','n'),(7,'checkboxes','1.0','YTowOnt9','n'),(8,'radio','1.0','YTowOnt9','n'),(9,'relationship','1.0','YTowOnt9','n'),(10,'rte','1.0','YTowOnt9','n');
/*!40000 ALTER TABLE `exp_fieldtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_file_categories`
--

DROP TABLE IF EXISTS `exp_file_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_file_categories` (
  `file_id` int(10) unsigned default NULL,
  `cat_id` int(10) unsigned default NULL,
  `sort` int(10) unsigned default '0',
  `is_cover` char(1) default 'n',
  KEY `file_id` (`file_id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_file_categories`
--

LOCK TABLES `exp_file_categories` WRITE;
/*!40000 ALTER TABLE `exp_file_categories` DISABLE KEYS */;
INSERT INTO `exp_file_categories` VALUES (9,4,0,'n'),(8,3,0,'n');
/*!40000 ALTER TABLE `exp_file_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_file_dimensions`
--

DROP TABLE IF EXISTS `exp_file_dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_file_dimensions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `upload_location_id` int(4) unsigned default NULL,
  `title` varchar(255) default '',
  `short_name` varchar(255) default '',
  `resize_type` varchar(50) default '',
  `width` int(10) default '0',
  `height` int(10) default '0',
  `watermark_id` int(4) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `upload_location_id` (`upload_location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_file_dimensions`
--

LOCK TABLES `exp_file_dimensions` WRITE;
/*!40000 ALTER TABLE `exp_file_dimensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_file_dimensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_file_watermarks`
--

DROP TABLE IF EXISTS `exp_file_watermarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_file_watermarks` (
  `wm_id` int(4) unsigned NOT NULL auto_increment,
  `wm_name` varchar(80) default NULL,
  `wm_type` varchar(10) default 'text',
  `wm_image_path` varchar(100) default NULL,
  `wm_test_image_path` varchar(100) default NULL,
  `wm_use_font` char(1) default 'y',
  `wm_font` varchar(30) default NULL,
  `wm_font_size` int(3) unsigned default NULL,
  `wm_text` varchar(100) default NULL,
  `wm_vrt_alignment` varchar(10) default 'top',
  `wm_hor_alignment` varchar(10) default 'left',
  `wm_padding` int(3) unsigned default NULL,
  `wm_opacity` int(3) unsigned default NULL,
  `wm_hor_offset` int(4) unsigned default NULL,
  `wm_vrt_offset` int(4) unsigned default NULL,
  `wm_x_transp` int(4) default NULL,
  `wm_y_transp` int(4) default NULL,
  `wm_font_color` varchar(7) default NULL,
  `wm_use_drop_shadow` char(1) default 'y',
  `wm_shadow_distance` int(3) unsigned default NULL,
  `wm_shadow_color` varchar(7) default NULL,
  PRIMARY KEY  (`wm_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_file_watermarks`
--

LOCK TABLES `exp_file_watermarks` WRITE;
/*!40000 ALTER TABLE `exp_file_watermarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_file_watermarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_files`
--

DROP TABLE IF EXISTS `exp_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_files` (
  `file_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned default '1',
  `title` varchar(255) default NULL,
  `upload_location_id` int(4) unsigned default '0',
  `rel_path` varchar(255) default NULL,
  `mime_type` varchar(255) default NULL,
  `file_name` varchar(255) default NULL,
  `file_size` int(10) default '0',
  `description` text,
  `credit` varchar(255) default NULL,
  `location` varchar(255) default NULL,
  `uploaded_by_member_id` int(10) unsigned default '0',
  `upload_date` int(10) default NULL,
  `modified_by_member_id` int(10) unsigned default '0',
  `modified_date` int(10) default NULL,
  `file_hw_original` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`file_id`),
  KEY `upload_location_id` (`upload_location_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_files`
--

LOCK TABLES `exp_files` WRITE;
/*!40000 ALTER TABLE `exp_files` DISABLE KEYS */;
INSERT INTO `exp_files` VALUES (14,1,'FHA Rate Term Refi Worksheet-Conv to FHA',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE FHA Rate  Term Refi Worksheet-Conv to FHA.pdf','application/pdf','AMC WHOLESALE FHA Rate  Term Refi Worksheet-Conv to FHA.pdf',29092,'','','',1,1371135520,1,1371505133,' '),(13,1,'Submission Stacking Order PDF',4,'/Applications/MAMP/htdocs/bench/uploads/loan_submissions/AMC wholesaleSUBMISSION STACKIN ORDER2.pdf','application/pdf','AMC wholesaleSUBMISSION STACKIN ORDER2.pdf',30446,'','','',1,1371152798,1,1371505974,' '),(12,1,'Submission Stacking Order .DOC',4,'/Applications/MAMP/htdocs/bench/uploads/loan_submissions/AMC wholesaleSUBMISSION STACKIN ORDER2.doc','application/msword','AMC wholesaleSUBMISSION STACKIN ORDER2.doc',122880,'','','',1,1371152798,1,1371506018,' '),(10,1,'FHA Loan Stacking Checklist',4,'/Applications/MAMP/htdocs/bench/uploads/loan_submissions/AMC Wholesale FHA Loan Stacking Checklist.pdf','application/pdf','AMC Wholesale FHA Loan Stacking Checklist.pdf',32638,'','','',1,1371152798,1,1371407147,' '),(11,1,'LDP GSA Checklist',4,'/Applications/MAMP/htdocs/bench/uploads/loan_submissions/AMC Wholesale LDP GSA Checklist.pdf','application/pdf','AMC Wholesale LDP GSA Checklist.pdf',46010,'','','',1,1371152798,1,1371407199,' '),(8,1,'FHA Case Number Request',4,'/Applications/MAMP/htdocs/bench/uploads/loan_submissions/AMC_Wholesale_FHA_Case_Number_Request.pdf','application/pdf','AMC_Wholesale_FHA_Case_Number_Request.pdf',22569,'','','',1,1371340547,1,1371407066,' '),(9,1,'Appraisal Independence Requirements Borrowers Acknowledgement',3,'/Applications/MAMP/htdocs/bench/uploads/appraisals/AMC_Wholesale_Appraisal_Independence_Requirements_Borrowers_Acknowledgement.pdf','application/pdf','AMC_Wholesale_Appraisal_Independence_Requirements_Borrowers_Acknowledgement.pdf',29307,'','','',1,1371341096,1,1371407087,' '),(15,1,'Flood Hazard Notice',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE FLOOD HAZARD NOTICE.pdf','application/pdf','AMC WHOLESALE FLOOD HAZARD NOTICE.pdf',14219,'','','',1,1371329690,1,1371505154,' '),(16,1,'Obtaining Permissions for Texas VLB',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE INSTRUCTIONS FOR OBTAINING PERMISSION FOR THE.pdf','application/pdf','AMC WHOLESALE INSTRUCTIONS FOR OBTAINING PERMISSION FOR THE.pdf',36733,'','','',1,1371135514,1,1371505077,' '),(17,1,'Mortgage Banker Disclosure',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE MORTGAGE BANKER DISCLOSURE.pdf','application/pdf','AMC WHOLESALE MORTGAGE BANKER DISCLOSURE.pdf',9155,'','','',1,1371135484,1,1371407297,' '),(18,1,'New File Submission Form',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE NEW FILE SUBMISSION FORM.pdf','application/pdf','AMC WHOLESALE NEW FILE SUBMISSION FORM.pdf',31141,'','','',1,1371329690,1,1371406954,' '),(19,1,'Respa Itemization of Fees',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE RESPA ITEMIZATION OF FEES.pdf','application/pdf','AMC WHOLESALE RESPA ITEMIZATION OF FEES.pdf',21836,'','','',1,1371135440,1,1371487238,' '),(20,1,'Respa Settlement Service Provider List',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE RESPA SETTLEMENT SERVICE PROVIDER LIST.pdf','application/pdf','AMC WHOLESALE RESPA SETTLEMENT SERVICE PROVIDER LIST.pdf',24374,'','','',1,1371135432,1,1371487269,' '),(21,1,'Social Security Validation Form',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WHOLESALE SOCIAL SECURITY VALIDATION FORM.pdf','application/pdf','AMC WHOLESALE SOCIAL SECURITY VALIDATION FORM.pdf',29861,'','','',1,1371135420,1,1371487290,' '),(22,1,'AUS Man Pre Qual',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale AUS Man Pre Qual.pdf','application/pdf','AMC Wholesale AUS Man Pre Qual.pdf',88199,'','','',1,1371329690,1,1371407120,' '),(23,1,'Appraisal Independence Requirements Borrowers Acknowledgement 1',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale Appraisal Independence Requirements Borrowers Acknowledgement 1.pdf','application/pdf','AMC Wholesale Appraisal Independence Requirements Borrowers Acknowledgement 1.pdf',29306,'','','',1,1371134696,1,1371487311,' '),(24,1,'Brokers Certification for the TIL Act',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale Brokers Certification for the TIL Act.pdf','application/pdf','AMC Wholesale Brokers Certification for the TIL Act.pdf',9834,'','','',1,1371134652,1,1371487325,' '),(25,1,'Closing Fee Sheet',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale Closing Fee Sheet.pdf','application/pdf','AMC Wholesale Closing Fee Sheet.pdf',34772,'','','',1,1371134568,1,1371487333,' '),(26,1,'FHA Case Number Request 1',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA Case Number Request 1.pdf','application/pdf','AMC Wholesale FHA Case Number Request 1.pdf',22573,'','','',1,1371133622,1,1371487631,' '),(27,1,'FHA Cash-Out Refi Worksheet-NA in Texas',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA Cash-Out Refi Worksheet-NA in Texas.pdf','application/pdf','AMC Wholesale FHA Cash-Out Refi Worksheet-NA in Texas.pdf',25487,'','','',1,1371133650,1,1371487625,' '),(28,1,'FHA Loan Stacking Checklist 1',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA Loan Stacking Checklist 1.pdf','application/pdf','AMC Wholesale FHA Loan Stacking Checklist 1.pdf',32638,'','','',1,1371133664,1,1371487612,' '),(29,1,'FHA Qualifying Test',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA QUALIFYING TEST.pdf','application/pdf','AMC Wholesale FHA QUALIFYING TEST.pdf',38219,'','','',1,1371133680,1,1371406936,' '),(30,1,'FHA Streamline Refi Worksheet WITH Appraisal',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA Streamline Refi Worksheet WITH Appraisal.pdf','application/pdf','AMC Wholesale FHA Streamline Refi Worksheet WITH Appraisal.pdf',29331,'','','',1,1371133698,1,1371487606,' '),(31,1,'FHA Streamline Refi Worksheet WITHOUT Appraisal',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA Streamline Refi Worksheet WITHOUT Appraisal.pdf','application/pdf','AMC Wholesale FHA Streamline Refi Worksheet WITHOUT Appraisal.pdf',24413,'','','',1,1371133704,1,1371487598,' '),(32,1,'FHA Streamline Refinance Tangible Worksheet',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale FHA Streamline Refinance tangible worksheet.pdf','application/pdf','AMC Wholesale FHA Streamline Refinance tangible worksheet.pdf',28841,'','','',1,1371133710,1,1371506615,' '),(33,1,'Immigration Classification and Visa Categories',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale IMMIGRATION CLASSIFICATION AND VISA CATAGORIES.pdf','application/pdf','AMC Wholesale IMMIGRATION CLASSIFICATION AND VISA CATAGORIES.pdf',67106,'','','',1,1371133972,1,1371487430,' '),(34,1,'LDP GSA Checklist 1',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale LDP GSA Checklist 1.pdf','application/pdf','AMC Wholesale LDP GSA Checklist 1.pdf',46010,'','','',1,1371135090,1,1371487303,' '),(35,1,'List of Lender-Broker and-or Seller Paid Fees-Credits',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale LIST OF LENDER-BROKER AND-OR SELLER PAID FEES-CREDITS.pdf','application/pdf','AMC Wholesale LIST OF LENDER-BROKER AND-OR SELLER PAID FEES-CREDITS.pdf',19643,'','','',1,1371133980,1,1371487366,' '),(36,1,'Monthly Budget',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale MONTHLY BUDGET.pdf','application/pdf','AMC Wholesale MONTHLY BUDGET.pdf',20824,'','','',1,1371133990,1,1371487343,' '),(37,1,'Multi-State Refinance Benefit Worksheet',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale Multi-State Refinance Benefit Worksheet.pdf','application/pdf','AMC Wholesale Multi-State Refinance Benefit Worksheet.pdf',68940,'','','',1,1371135462,1,1371407307,' '),(38,1,'Occupancy Certification',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale OCCUPANCY CERTIFICATION.pdf','application/pdf','AMC Wholesale OCCUPANCY CERTIFICATION.pdf',30771,'','','',1,1371135450,1,1371487253,' '),(39,1,'Undisclosed Debt Acknowledgement',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale Undisclosed debt acknowledgement.pdf','application/pdf','AMC Wholesale Undisclosed debt acknowledgement.pdf',265953,'','','',1,1371056234,1,1371406984,' '),(40,1,'VA Lender Certification',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale VA LENDER CERTIFICATION.pdf','application/pdf','AMC Wholesale VA LENDER CERTIFICATION.pdf',26700,'','','',1,1371067682,1,1371505288,' '),(41,1,'VA Questionnaire',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale VA Questionnaire.pdf','application/pdf','AMC Wholesale VA Questionnaire.pdf',70768,'','','',1,1371067516,1,1371487646,' '),(42,1,'VA Comparison Statment',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale VA comparison statmentpdf.pdf','application/pdf','AMC Wholesale VA comparison statmentpdf.pdf',24755,'','','',1,1371064354,1,1371505214,' '),(43,1,'Verbal Voe',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale Verbal Voe.pdf','application/pdf','AMC Wholesale Verbal Voe.pdf',18707,'','','',1,1371134658,1,1371487318,' '),(44,1,'VA Lender Certification',9,'/Applications/MAMP/htdocs/bench/uploads/forms/VA LENDER CERTIFICATION pdf.pdf','application/pdf','VA LENDER CERTIFICATION pdf.pdf',26698,'','','',1,1371064494,1,1371505424,' '),(45,1,'Changed Circumstance Letter',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC Wholesale changed circumstance letter.doc','application/msword','AMC Wholesale changed circumstance letter.doc',27136,'','','',1,1371135810,1,1371407175,' '),(46,1,'FHA Purchase Transaction Mtg Loan Amt Calculator 109',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC WholesaleFHA Purchase Transaction Mtg Loan Amt Calculator 109.pdf','application/pdf','AMC WholesaleFHA Purchase Transaction Mtg Loan Amt Calculator 109.pdf',26100,'','','',1,1371133718,1,1371487440,' '),(47,1,'Texas Veterans Housing Assistance Program',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC wholesaleTEXAS VETERANS HOUSING ASSISTANCE PROGRAM.pdf','application/pdf','AMC wholesaleTEXAS VETERANS HOUSING ASSISTANCE PROGRAM.pdf',21654,'','','',1,1371067340,1,1371505611,' '),(48,1,'Three Year Occupancy Disclosure',9,'/Applications/MAMP/htdocs/bench/uploads/forms/AMC wholesaleTHREE YEAR OCCUPANCY DISCLOSURE.pdf','application/pdf','AMC wholesaleTHREE YEAR OCCUPANCY DISCLOSURE.pdf',29493,'','','',1,1371065210,1,1371505540,' '),(49,1,'Broker Checklist',8,'/home/jordotech/webapps/bench/uploads/signup/Broker_Checklist.pdf','application/pdf','Broker_Checklist.pdf',90419,'','','',1,1371488857,1,1371488870,' '),(50,1,'AMC Broker Application',8,'/home/jordotech/webapps/bench/uploads/signup/AMC_BROKER_APPLICATION.pdf','application/pdf','AMC_BROKER_APPLICATION.pdf',108472,'','','',1,1371488885,1,1371488896,' '),(51,1,'AMC Broker Agreement',8,'/home/jordotech/webapps/bench/uploads/signup/AMC_BROKER_AGREEMENT.pdf','application/pdf','AMC_BROKER_AGREEMENT.pdf',143729,'','','',1,1371488909,1,1371488920,' '),(52,1,'Addendum to AMC Broker Agreement',8,'/home/jordotech/webapps/bench/uploads/signup/ADDENDUM_TO_MORTGAGE_BROKER_AGREEMENT.pdf','application/pdf','ADDENDUM_TO_MORTGAGE_BROKER_AGREEMENT.pdf',102973,'','','',1,1371488937,1,1371488951,' '),(53,1,'W-9',8,'/home/jordotech/webapps/bench/uploads/signup/W-9_2011.pdf','application/pdf','W-9_2011.pdf',90102,'','','',1,1371489098,1,1371489103,' '),(54,1,'AMC Broker FAX/Email Permission',8,'/home/jordotech/webapps/bench/uploads/signup/AMC_FAX_EMAIL_PERMISSION.pdf','application/pdf','AMC_FAX_EMAIL_PERMISSION.pdf',96737,'','','',1,1371489120,1,1371489137,' '),(57,1,'BMB Loan Purchase Program Application Mini',10,'/home/jordotech/webapps/bench/uploads/bin/BMB_Loan_Purchase_Program_Application_Mini.pdf','application/pdf','BMB_Loan_Purchase_Program_Application_Mini.pdf',66560,'','','',1,1371489973,1,1371489991,' '),(58,1,'Wholesale Warehouse Silver Program with Contact',10,'/home/jordotech/webapps/bench/uploads/bin/Wholesale_Warehouse_Silver_Program_with_Contact.pdf','application/pdf','Wholesale_Warehouse_Silver_Program_with_Contact.pdf',115958,'','','',1,1371490005,1,1371490022,' ');
/*!40000 ALTER TABLE `exp_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_global_variables`
--

DROP TABLE IF EXISTS `exp_global_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_global_variables` (
  `variable_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `variable_name` varchar(50) NOT NULL,
  `variable_data` text NOT NULL,
  PRIMARY KEY  (`variable_id`),
  KEY `variable_name` (`variable_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_global_variables`
--

LOCK TABLES `exp_global_variables` WRITE;
/*!40000 ALTER TABLE `exp_global_variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_global_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_html_buttons`
--

DROP TABLE IF EXISTS `exp_html_buttons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_html_buttons` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `member_id` int(10) NOT NULL default '0',
  `tag_name` varchar(32) NOT NULL,
  `tag_open` varchar(120) NOT NULL,
  `tag_close` varchar(120) NOT NULL,
  `accesskey` varchar(32) NOT NULL,
  `tag_order` int(3) unsigned NOT NULL,
  `tag_row` char(1) NOT NULL default '1',
  `classname` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_html_buttons`
--

LOCK TABLES `exp_html_buttons` WRITE;
/*!40000 ALTER TABLE `exp_html_buttons` DISABLE KEYS */;
INSERT INTO `exp_html_buttons` VALUES (1,1,0,'b','<strong>','</strong>','b',1,'1','btn_b'),(2,1,0,'i','<em>','</em>','i',2,'1','btn_i'),(3,1,0,'blockquote','<blockquote>','</blockquote>','q',3,'1','btn_blockquote'),(4,1,0,'a','<a href=\"[![Link:!:http://]!]\"(!( title=\"[![Title]!]\")!)>','</a>','a',4,'1','btn_a'),(5,1,0,'img','<img src=\"[![Link:!:http://]!]\" alt=\"[![Alternative text]!]\" />','','',5,'1','btn_img');
/*!40000 ALTER TABLE `exp_html_buttons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_layout_publish`
--

DROP TABLE IF EXISTS `exp_layout_publish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_layout_publish` (
  `layout_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `member_group` int(4) unsigned NOT NULL default '0',
  `channel_id` int(4) unsigned NOT NULL default '0',
  `field_layout` text,
  PRIMARY KEY  (`layout_id`),
  KEY `site_id` (`site_id`),
  KEY `member_group` (`member_group`),
  KEY `channel_id` (`channel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_layout_publish`
--

LOCK TABLES `exp_layout_publish` WRITE;
/*!40000 ALTER TABLE `exp_layout_publish` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_layout_publish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_member_bulletin_board`
--

DROP TABLE IF EXISTS `exp_member_bulletin_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_member_bulletin_board` (
  `bulletin_id` int(10) unsigned NOT NULL auto_increment,
  `sender_id` int(10) unsigned NOT NULL,
  `bulletin_group` int(8) unsigned NOT NULL,
  `bulletin_date` int(10) unsigned NOT NULL,
  `hash` varchar(10) NOT NULL default '',
  `bulletin_expires` int(10) unsigned NOT NULL default '0',
  `bulletin_message` text NOT NULL,
  PRIMARY KEY  (`bulletin_id`),
  KEY `sender_id` (`sender_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_member_bulletin_board`
--

LOCK TABLES `exp_member_bulletin_board` WRITE;
/*!40000 ALTER TABLE `exp_member_bulletin_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_member_bulletin_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_member_data`
--

DROP TABLE IF EXISTS `exp_member_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_member_data` (
  `member_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_member_data`
--

LOCK TABLES `exp_member_data` WRITE;
/*!40000 ALTER TABLE `exp_member_data` DISABLE KEYS */;
INSERT INTO `exp_member_data` VALUES (1);
/*!40000 ALTER TABLE `exp_member_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_member_fields`
--

DROP TABLE IF EXISTS `exp_member_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_member_fields` (
  `m_field_id` int(4) unsigned NOT NULL auto_increment,
  `m_field_name` varchar(32) NOT NULL,
  `m_field_label` varchar(50) NOT NULL,
  `m_field_description` text NOT NULL,
  `m_field_type` varchar(12) NOT NULL default 'text',
  `m_field_list_items` text NOT NULL,
  `m_field_ta_rows` tinyint(2) default '8',
  `m_field_maxl` smallint(3) NOT NULL,
  `m_field_width` varchar(6) NOT NULL,
  `m_field_search` char(1) NOT NULL default 'y',
  `m_field_required` char(1) NOT NULL default 'n',
  `m_field_public` char(1) NOT NULL default 'y',
  `m_field_reg` char(1) NOT NULL default 'n',
  `m_field_cp_reg` char(1) NOT NULL default 'n',
  `m_field_fmt` char(5) NOT NULL default 'none',
  `m_field_order` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`m_field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_member_fields`
--

LOCK TABLES `exp_member_fields` WRITE;
/*!40000 ALTER TABLE `exp_member_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_member_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_member_groups`
--

DROP TABLE IF EXISTS `exp_member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_title` varchar(100) NOT NULL,
  `group_description` text NOT NULL,
  `is_locked` char(1) NOT NULL default 'y',
  `can_view_offline_system` char(1) NOT NULL default 'n',
  `can_view_online_system` char(1) NOT NULL default 'y',
  `can_access_cp` char(1) NOT NULL default 'y',
  `can_access_content` char(1) NOT NULL default 'n',
  `can_access_publish` char(1) NOT NULL default 'n',
  `can_access_edit` char(1) NOT NULL default 'n',
  `can_access_files` char(1) NOT NULL default 'n',
  `can_access_fieldtypes` char(1) NOT NULL default 'n',
  `can_access_design` char(1) NOT NULL default 'n',
  `can_access_addons` char(1) NOT NULL default 'n',
  `can_access_modules` char(1) NOT NULL default 'n',
  `can_access_extensions` char(1) NOT NULL default 'n',
  `can_access_accessories` char(1) NOT NULL default 'n',
  `can_access_plugins` char(1) NOT NULL default 'n',
  `can_access_members` char(1) NOT NULL default 'n',
  `can_access_admin` char(1) NOT NULL default 'n',
  `can_access_sys_prefs` char(1) NOT NULL default 'n',
  `can_access_content_prefs` char(1) NOT NULL default 'n',
  `can_access_tools` char(1) NOT NULL default 'n',
  `can_access_comm` char(1) NOT NULL default 'n',
  `can_access_utilities` char(1) NOT NULL default 'n',
  `can_access_data` char(1) NOT NULL default 'n',
  `can_access_logs` char(1) NOT NULL default 'n',
  `can_admin_channels` char(1) NOT NULL default 'n',
  `can_admin_upload_prefs` char(1) NOT NULL default 'n',
  `can_admin_design` char(1) NOT NULL default 'n',
  `can_admin_members` char(1) NOT NULL default 'n',
  `can_delete_members` char(1) NOT NULL default 'n',
  `can_admin_mbr_groups` char(1) NOT NULL default 'n',
  `can_admin_mbr_templates` char(1) NOT NULL default 'n',
  `can_ban_users` char(1) NOT NULL default 'n',
  `can_admin_modules` char(1) NOT NULL default 'n',
  `can_admin_templates` char(1) NOT NULL default 'n',
  `can_edit_categories` char(1) NOT NULL default 'n',
  `can_delete_categories` char(1) NOT NULL default 'n',
  `can_view_other_entries` char(1) NOT NULL default 'n',
  `can_edit_other_entries` char(1) NOT NULL default 'n',
  `can_assign_post_authors` char(1) NOT NULL default 'n',
  `can_delete_self_entries` char(1) NOT NULL default 'n',
  `can_delete_all_entries` char(1) NOT NULL default 'n',
  `can_view_other_comments` char(1) NOT NULL default 'n',
  `can_edit_own_comments` char(1) NOT NULL default 'n',
  `can_delete_own_comments` char(1) NOT NULL default 'n',
  `can_edit_all_comments` char(1) NOT NULL default 'n',
  `can_delete_all_comments` char(1) NOT NULL default 'n',
  `can_moderate_comments` char(1) NOT NULL default 'n',
  `can_send_email` char(1) NOT NULL default 'n',
  `can_send_cached_email` char(1) NOT NULL default 'n',
  `can_email_member_groups` char(1) NOT NULL default 'n',
  `can_email_mailinglist` char(1) NOT NULL default 'n',
  `can_email_from_profile` char(1) NOT NULL default 'n',
  `can_view_profiles` char(1) NOT NULL default 'n',
  `can_edit_html_buttons` char(1) NOT NULL default 'n',
  `can_delete_self` char(1) NOT NULL default 'n',
  `mbr_delete_notify_emails` varchar(255) default NULL,
  `can_post_comments` char(1) NOT NULL default 'n',
  `exclude_from_moderation` char(1) NOT NULL default 'n',
  `can_search` char(1) NOT NULL default 'n',
  `search_flood_control` mediumint(5) unsigned NOT NULL,
  `can_send_private_messages` char(1) NOT NULL default 'n',
  `prv_msg_send_limit` smallint(5) unsigned NOT NULL default '20',
  `prv_msg_storage_limit` smallint(5) unsigned NOT NULL default '60',
  `can_attach_in_private_messages` char(1) NOT NULL default 'n',
  `can_send_bulletins` char(1) NOT NULL default 'n',
  `include_in_authorlist` char(1) NOT NULL default 'n',
  `include_in_memberlist` char(1) NOT NULL default 'y',
  `include_in_mailinglists` char(1) NOT NULL default 'y',
  PRIMARY KEY  (`group_id`,`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_member_groups`
--

LOCK TABLES `exp_member_groups` WRITE;
/*!40000 ALTER TABLE `exp_member_groups` DISABLE KEYS */;
INSERT INTO `exp_member_groups` VALUES (1,1,'Super Admins','','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','','y','y','y',0,'y',20,60,'y','y','y','y','y'),(2,1,'Banned','','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','','n','n','n',60,'n',20,60,'n','n','n','n','n'),(3,1,'Guests','','y','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','y','n','n','n','n','','y','n','y',15,'n',20,60,'n','n','n','n','n'),(4,1,'Pending','','y','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','y','n','n','n','n','','y','n','y',15,'n',20,60,'n','n','n','n','n'),(5,1,'Members','','y','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','y','y','y','n','','y','n','y',10,'y',20,60,'y','n','n','y','y');
/*!40000 ALTER TABLE `exp_member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_member_homepage`
--

DROP TABLE IF EXISTS `exp_member_homepage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_member_homepage` (
  `member_id` int(10) unsigned NOT NULL,
  `recent_entries` char(1) NOT NULL default 'l',
  `recent_entries_order` int(3) unsigned NOT NULL default '0',
  `recent_comments` char(1) NOT NULL default 'l',
  `recent_comments_order` int(3) unsigned NOT NULL default '0',
  `recent_members` char(1) NOT NULL default 'n',
  `recent_members_order` int(3) unsigned NOT NULL default '0',
  `site_statistics` char(1) NOT NULL default 'r',
  `site_statistics_order` int(3) unsigned NOT NULL default '0',
  `member_search_form` char(1) NOT NULL default 'n',
  `member_search_form_order` int(3) unsigned NOT NULL default '0',
  `notepad` char(1) NOT NULL default 'r',
  `notepad_order` int(3) unsigned NOT NULL default '0',
  `bulletin_board` char(1) NOT NULL default 'r',
  `bulletin_board_order` int(3) unsigned NOT NULL default '0',
  `pmachine_news_feed` char(1) NOT NULL default 'n',
  `pmachine_news_feed_order` int(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_member_homepage`
--

LOCK TABLES `exp_member_homepage` WRITE;
/*!40000 ALTER TABLE `exp_member_homepage` DISABLE KEYS */;
INSERT INTO `exp_member_homepage` VALUES (1,'l',1,'l',2,'n',0,'r',1,'n',0,'r',2,'r',0,'l',0);
/*!40000 ALTER TABLE `exp_member_homepage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_member_search`
--

DROP TABLE IF EXISTS `exp_member_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_member_search` (
  `search_id` varchar(32) NOT NULL,
  `site_id` int(4) unsigned NOT NULL default '1',
  `search_date` int(10) unsigned NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `fields` varchar(200) NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `total_results` int(8) unsigned NOT NULL,
  `query` text NOT NULL,
  PRIMARY KEY  (`search_id`),
  KEY `member_id` (`member_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_member_search`
--

LOCK TABLES `exp_member_search` WRITE;
/*!40000 ALTER TABLE `exp_member_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_member_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_members`
--

DROP TABLE IF EXISTS `exp_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_members` (
  `member_id` int(10) unsigned NOT NULL auto_increment,
  `group_id` smallint(4) NOT NULL default '0',
  `username` varchar(50) NOT NULL,
  `screen_name` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `salt` varchar(128) NOT NULL default '',
  `unique_id` varchar(40) NOT NULL,
  `crypt_key` varchar(40) default NULL,
  `authcode` varchar(10) default NULL,
  `email` varchar(72) NOT NULL,
  `url` varchar(150) default NULL,
  `location` varchar(50) default NULL,
  `occupation` varchar(80) default NULL,
  `interests` varchar(120) default NULL,
  `bday_d` int(2) default NULL,
  `bday_m` int(2) default NULL,
  `bday_y` int(4) default NULL,
  `aol_im` varchar(50) default NULL,
  `yahoo_im` varchar(50) default NULL,
  `msn_im` varchar(50) default NULL,
  `icq` varchar(50) default NULL,
  `bio` text,
  `signature` text,
  `avatar_filename` varchar(120) default NULL,
  `avatar_width` int(4) unsigned default NULL,
  `avatar_height` int(4) unsigned default NULL,
  `photo_filename` varchar(120) default NULL,
  `photo_width` int(4) unsigned default NULL,
  `photo_height` int(4) unsigned default NULL,
  `sig_img_filename` varchar(120) default NULL,
  `sig_img_width` int(4) unsigned default NULL,
  `sig_img_height` int(4) unsigned default NULL,
  `ignore_list` text,
  `private_messages` int(4) unsigned NOT NULL default '0',
  `accept_messages` char(1) NOT NULL default 'y',
  `last_view_bulletins` int(10) NOT NULL default '0',
  `last_bulletin_date` int(10) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `join_date` int(10) unsigned NOT NULL default '0',
  `last_visit` int(10) unsigned NOT NULL default '0',
  `last_activity` int(10) unsigned NOT NULL default '0',
  `total_entries` mediumint(8) unsigned NOT NULL default '0',
  `total_comments` mediumint(8) unsigned NOT NULL default '0',
  `total_forum_topics` mediumint(8) NOT NULL default '0',
  `total_forum_posts` mediumint(8) NOT NULL default '0',
  `last_entry_date` int(10) unsigned NOT NULL default '0',
  `last_comment_date` int(10) unsigned NOT NULL default '0',
  `last_forum_post_date` int(10) unsigned NOT NULL default '0',
  `last_email_date` int(10) unsigned NOT NULL default '0',
  `in_authorlist` char(1) NOT NULL default 'n',
  `accept_admin_email` char(1) NOT NULL default 'y',
  `accept_user_email` char(1) NOT NULL default 'y',
  `notify_by_default` char(1) NOT NULL default 'y',
  `notify_of_pm` char(1) NOT NULL default 'y',
  `display_avatars` char(1) NOT NULL default 'y',
  `display_signatures` char(1) NOT NULL default 'y',
  `parse_smileys` char(1) NOT NULL default 'y',
  `smart_notifications` char(1) NOT NULL default 'y',
  `language` varchar(50) NOT NULL,
  `timezone` varchar(50) NOT NULL,
  `localization_is_site_default` char(1) NOT NULL default 'n',
  `time_format` char(2) NOT NULL default 'us',
  `cp_theme` varchar(32) default NULL,
  `profile_theme` varchar(32) default NULL,
  `forum_theme` varchar(32) default NULL,
  `tracker` text,
  `template_size` varchar(2) NOT NULL default '28',
  `notepad` text,
  `notepad_size` varchar(2) NOT NULL default '18',
  `quick_links` text,
  `quick_tabs` text,
  `show_sidebar` char(1) NOT NULL default 'n',
  `pmember_id` int(10) NOT NULL default '0',
  `rte_enabled` char(1) NOT NULL default 'y',
  `rte_toolset_id` int(10) NOT NULL default '0',
  PRIMARY KEY  (`member_id`),
  KEY `group_id` (`group_id`),
  KEY `unique_id` (`unique_id`),
  KEY `password` (`password`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_members`
--

LOCK TABLES `exp_members` WRITE;
/*!40000 ALTER TABLE `exp_members` DISABLE KEYS */;
INSERT INTO `exp_members` VALUES (1,1,'admin','admin','f780c15f705e63cdb406f06e1df7163cde126e9a4efb7292e3e1a9f57906bf25659a12128879fb13fe114cc04b033d196419c23cf423bc2b1b5ac4877c28e858','c[Y5,|u\\7i4`}!CL@sKQ|MaAm:ul[Pr/o+WKt[9,?o\"gXOR]{U=D48oLP5?$d.TzDt);LWA).VQJvvVp8i8Xw4~({?dbixb%[7AhZ>lc;3\\7a&97<rP?{5yfw)n496t#','bcc8659270a23ad9904f398ea2a5b91b4d76532d','9071c89bba4ef7d3064d345385f0a6c13413970e',NULL,'jordotech@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'y',0,0,'127.0.0.1',1371057244,1371494865,1371507219,18,0,0,0,1371406593,0,0,0,'n','y','y','y','y','y','y','y','y','english','America/Chicago','n','us',NULL,NULL,NULL,NULL,'28',NULL,'18','','View Entry|C=content_publish&M=view_entry&channel_id=2&entry_id=13|1\nPages|C=addons_modules&M=show_module_cp&module=pages|2','y',0,'y',0);
/*!40000 ALTER TABLE `exp_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_message_attachments`
--

DROP TABLE IF EXISTS `exp_message_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_message_attachments` (
  `attachment_id` int(10) unsigned NOT NULL auto_increment,
  `sender_id` int(10) unsigned NOT NULL default '0',
  `message_id` int(10) unsigned NOT NULL default '0',
  `attachment_name` varchar(50) NOT NULL default '',
  `attachment_hash` varchar(40) NOT NULL default '',
  `attachment_extension` varchar(20) NOT NULL default '',
  `attachment_location` varchar(150) NOT NULL default '',
  `attachment_date` int(10) unsigned NOT NULL default '0',
  `attachment_size` int(10) unsigned NOT NULL default '0',
  `is_temp` char(1) NOT NULL default 'y',
  PRIMARY KEY  (`attachment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_message_attachments`
--

LOCK TABLES `exp_message_attachments` WRITE;
/*!40000 ALTER TABLE `exp_message_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_message_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_message_copies`
--

DROP TABLE IF EXISTS `exp_message_copies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_message_copies` (
  `copy_id` int(10) unsigned NOT NULL auto_increment,
  `message_id` int(10) unsigned NOT NULL default '0',
  `sender_id` int(10) unsigned NOT NULL default '0',
  `recipient_id` int(10) unsigned NOT NULL default '0',
  `message_received` char(1) NOT NULL default 'n',
  `message_read` char(1) NOT NULL default 'n',
  `message_time_read` int(10) unsigned NOT NULL default '0',
  `attachment_downloaded` char(1) NOT NULL default 'n',
  `message_folder` int(10) unsigned NOT NULL default '1',
  `message_authcode` varchar(10) NOT NULL default '',
  `message_deleted` char(1) NOT NULL default 'n',
  `message_status` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`copy_id`),
  KEY `message_id` (`message_id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_message_copies`
--

LOCK TABLES `exp_message_copies` WRITE;
/*!40000 ALTER TABLE `exp_message_copies` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_message_copies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_message_data`
--

DROP TABLE IF EXISTS `exp_message_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_message_data` (
  `message_id` int(10) unsigned NOT NULL auto_increment,
  `sender_id` int(10) unsigned NOT NULL default '0',
  `message_date` int(10) unsigned NOT NULL default '0',
  `message_subject` varchar(255) NOT NULL default '',
  `message_body` text NOT NULL,
  `message_tracking` char(1) NOT NULL default 'y',
  `message_attachments` char(1) NOT NULL default 'n',
  `message_recipients` varchar(200) NOT NULL default '',
  `message_cc` varchar(200) NOT NULL default '',
  `message_hide_cc` char(1) NOT NULL default 'n',
  `message_sent_copy` char(1) NOT NULL default 'n',
  `total_recipients` int(5) unsigned NOT NULL default '0',
  `message_status` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`message_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_message_data`
--

LOCK TABLES `exp_message_data` WRITE;
/*!40000 ALTER TABLE `exp_message_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_message_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_message_folders`
--

DROP TABLE IF EXISTS `exp_message_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_message_folders` (
  `member_id` int(10) unsigned NOT NULL default '0',
  `folder1_name` varchar(50) NOT NULL default 'InBox',
  `folder2_name` varchar(50) NOT NULL default 'Sent',
  `folder3_name` varchar(50) NOT NULL default '',
  `folder4_name` varchar(50) NOT NULL default '',
  `folder5_name` varchar(50) NOT NULL default '',
  `folder6_name` varchar(50) NOT NULL default '',
  `folder7_name` varchar(50) NOT NULL default '',
  `folder8_name` varchar(50) NOT NULL default '',
  `folder9_name` varchar(50) NOT NULL default '',
  `folder10_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_message_folders`
--

LOCK TABLES `exp_message_folders` WRITE;
/*!40000 ALTER TABLE `exp_message_folders` DISABLE KEYS */;
INSERT INTO `exp_message_folders` VALUES (1,'InBox','Sent','','','','','','','','');
/*!40000 ALTER TABLE `exp_message_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_message_listed`
--

DROP TABLE IF EXISTS `exp_message_listed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_message_listed` (
  `listed_id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) unsigned NOT NULL default '0',
  `listed_member` int(10) unsigned NOT NULL default '0',
  `listed_description` varchar(100) NOT NULL default '',
  `listed_type` varchar(10) NOT NULL default 'blocked',
  PRIMARY KEY  (`listed_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_message_listed`
--

LOCK TABLES `exp_message_listed` WRITE;
/*!40000 ALTER TABLE `exp_message_listed` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_message_listed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_metaweblog_api`
--

DROP TABLE IF EXISTS `exp_metaweblog_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_metaweblog_api` (
  `metaweblog_id` int(5) unsigned NOT NULL auto_increment,
  `metaweblog_pref_name` varchar(80) NOT NULL default '',
  `metaweblog_parse_type` varchar(1) NOT NULL default 'y',
  `entry_status` varchar(50) NOT NULL default 'NULL',
  `field_group_id` int(5) unsigned NOT NULL default '0',
  `excerpt_field_id` int(7) unsigned NOT NULL default '0',
  `content_field_id` int(7) unsigned NOT NULL default '0',
  `more_field_id` int(7) unsigned NOT NULL default '0',
  `keywords_field_id` int(7) unsigned NOT NULL default '0',
  `upload_dir` int(5) unsigned NOT NULL default '1',
  PRIMARY KEY  (`metaweblog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_metaweblog_api`
--

LOCK TABLES `exp_metaweblog_api` WRITE;
/*!40000 ALTER TABLE `exp_metaweblog_api` DISABLE KEYS */;
INSERT INTO `exp_metaweblog_api` VALUES (1,'Default','y','NULL',1,0,2,0,0,1);
/*!40000 ALTER TABLE `exp_metaweblog_api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_module_member_groups`
--

DROP TABLE IF EXISTS `exp_module_member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_module_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `module_id` mediumint(5) unsigned NOT NULL,
  PRIMARY KEY  (`group_id`,`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_module_member_groups`
--

LOCK TABLES `exp_module_member_groups` WRITE;
/*!40000 ALTER TABLE `exp_module_member_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_module_member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_modules`
--

DROP TABLE IF EXISTS `exp_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_modules` (
  `module_id` int(4) unsigned NOT NULL auto_increment,
  `module_name` varchar(50) NOT NULL,
  `module_version` varchar(12) NOT NULL,
  `has_cp_backend` char(1) NOT NULL default 'n',
  `has_publish_fields` char(1) NOT NULL default 'n',
  PRIMARY KEY  (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_modules`
--

LOCK TABLES `exp_modules` WRITE;
/*!40000 ALTER TABLE `exp_modules` DISABLE KEYS */;
INSERT INTO `exp_modules` VALUES (1,'Comment','2.3.1','y','n'),(2,'Emoticon','2.0','n','n'),(3,'File','1.0.0','n','n'),(4,'Jquery','1.0','n','n'),(5,'Metaweblog_api','2.1','y','n'),(6,'Pages','2.2','y','y'),(7,'Rss','2.0','n','n'),(8,'Referrer','2.1.1','y','n'),(9,'Safecracker','2.1','y','n'),(10,'Search','2.2.1','n','n'),(11,'Channel','2.0.1','n','n'),(12,'Stats','2.0','n','n'),(13,'Rte','1.0','y','n'),(14,'Deeploy_helper','2.0.3','y','n');
/*!40000 ALTER TABLE `exp_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_online_users`
--

DROP TABLE IF EXISTS `exp_online_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_online_users` (
  `online_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `member_id` int(10) NOT NULL default '0',
  `in_forum` char(1) NOT NULL default 'n',
  `name` varchar(50) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `date` int(10) unsigned NOT NULL default '0',
  `anon` char(1) NOT NULL,
  PRIMARY KEY  (`online_id`),
  KEY `date` (`date`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_online_users`
--

LOCK TABLES `exp_online_users` WRITE;
/*!40000 ALTER TABLE `exp_online_users` DISABLE KEYS */;
INSERT INTO `exp_online_users` VALUES (84,1,1,'n','admin','24.155.109.33',1371507247,''),(83,1,0,'n','','24.155.109.33',1371507688,''),(82,1,1,'n','admin','107.202.218.108',1371507281,'');
/*!40000 ALTER TABLE `exp_online_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_pages_configuration`
--

DROP TABLE IF EXISTS `exp_pages_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_pages_configuration` (
  `configuration_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(8) unsigned NOT NULL default '1',
  `configuration_name` varchar(60) NOT NULL,
  `configuration_value` varchar(100) NOT NULL,
  PRIMARY KEY  (`configuration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_pages_configuration`
--

LOCK TABLES `exp_pages_configuration` WRITE;
/*!40000 ALTER TABLE `exp_pages_configuration` DISABLE KEYS */;
INSERT INTO `exp_pages_configuration` VALUES (1,1,'homepage_display','not_nested'),(2,1,'default_channel','1'),(3,1,'template_channel_1','1');
/*!40000 ALTER TABLE `exp_pages_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_password_lockout`
--

DROP TABLE IF EXISTS `exp_password_lockout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_password_lockout` (
  `lockout_id` int(10) unsigned NOT NULL auto_increment,
  `login_date` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY  (`lockout_id`),
  KEY `login_date` (`login_date`),
  KEY `ip_address` (`ip_address`),
  KEY `user_agent` (`user_agent`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_password_lockout`
--

LOCK TABLES `exp_password_lockout` WRITE;
/*!40000 ALTER TABLE `exp_password_lockout` DISABLE KEYS */;
INSERT INTO `exp_password_lockout` VALUES (1,1371326633,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:21.0) Gecko/20100101 Firefox/21.0 FirePHP/0.7.2','admin'),(2,1371406739,'24.155.109.33','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36','admin'),(3,1371486972,'24.155.109.33','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36','admin');
/*!40000 ALTER TABLE `exp_password_lockout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_ping_servers`
--

DROP TABLE IF EXISTS `exp_ping_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_ping_servers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `member_id` int(10) NOT NULL default '0',
  `server_name` varchar(32) NOT NULL,
  `server_url` varchar(150) NOT NULL,
  `port` varchar(4) NOT NULL default '80',
  `ping_protocol` varchar(12) NOT NULL default 'xmlrpc',
  `is_default` char(1) NOT NULL default 'y',
  `server_order` int(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_ping_servers`
--

LOCK TABLES `exp_ping_servers` WRITE;
/*!40000 ALTER TABLE `exp_ping_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_ping_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_referrers`
--

DROP TABLE IF EXISTS `exp_referrers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_referrers` (
  `ref_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) default '1',
  `ref_from` varchar(150) default NULL,
  `ref_to` varchar(120) default NULL,
  `ref_ip` varchar(45) default NULL,
  `ref_date` int(10) unsigned default '0',
  `ref_agent` varchar(100) default NULL,
  PRIMARY KEY  (`ref_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_referrers`
--

LOCK TABLES `exp_referrers` WRITE;
/*!40000 ALTER TABLE `exp_referrers` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_referrers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_relationships`
--

DROP TABLE IF EXISTS `exp_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_relationships` (
  `relationship_id` int(6) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned NOT NULL default '0',
  `child_id` int(10) unsigned NOT NULL default '0',
  `field_id` int(10) unsigned NOT NULL default '0',
  `order` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`relationship_id`),
  KEY `parent_id` (`parent_id`),
  KEY `child_id` (`child_id`),
  KEY `field_id` (`field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_relationships`
--

LOCK TABLES `exp_relationships` WRITE;
/*!40000 ALTER TABLE `exp_relationships` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_remember_me`
--

DROP TABLE IF EXISTS `exp_remember_me`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_remember_me` (
  `remember_me_id` varchar(40) NOT NULL default '0',
  `member_id` int(10) default '0',
  `ip_address` varchar(45) default '0',
  `user_agent` varchar(120) default '',
  `admin_sess` tinyint(1) default '0',
  `site_id` int(4) default '1',
  `expiration` int(10) default '0',
  `last_refresh` int(10) default '0',
  PRIMARY KEY  (`remember_me_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_remember_me`
--

LOCK TABLES `exp_remember_me` WRITE;
/*!40000 ALTER TABLE `exp_remember_me` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_remember_me` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_reset_password`
--

DROP TABLE IF EXISTS `exp_reset_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_reset_password` (
  `reset_id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) unsigned NOT NULL,
  `resetcode` varchar(12) NOT NULL,
  `date` int(10) NOT NULL,
  PRIMARY KEY  (`reset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_reset_password`
--

LOCK TABLES `exp_reset_password` WRITE;
/*!40000 ALTER TABLE `exp_reset_password` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_reset_password` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_revision_tracker`
--

DROP TABLE IF EXISTS `exp_revision_tracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_revision_tracker` (
  `tracker_id` int(10) unsigned NOT NULL auto_increment,
  `item_id` int(10) unsigned NOT NULL,
  `item_table` varchar(20) NOT NULL,
  `item_field` varchar(20) NOT NULL,
  `item_date` int(10) NOT NULL,
  `item_author_id` int(10) unsigned NOT NULL,
  `item_data` mediumtext NOT NULL,
  PRIMARY KEY  (`tracker_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_revision_tracker`
--

LOCK TABLES `exp_revision_tracker` WRITE;
/*!40000 ALTER TABLE `exp_revision_tracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_revision_tracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_rte_tools`
--

DROP TABLE IF EXISTS `exp_rte_tools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_rte_tools` (
  `tool_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(75) default NULL,
  `class` varchar(75) default NULL,
  `enabled` char(1) default 'y',
  PRIMARY KEY  (`tool_id`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_rte_tools`
--

LOCK TABLES `exp_rte_tools` WRITE;
/*!40000 ALTER TABLE `exp_rte_tools` DISABLE KEYS */;
INSERT INTO `exp_rte_tools` VALUES (1,'Blockquote','Blockquote_rte','y'),(2,'Bold','Bold_rte','y'),(3,'Headings','Headings_rte','y'),(4,'Image','Image_rte','y'),(5,'Italic','Italic_rte','y'),(6,'Link','Link_rte','y'),(7,'Ordered List','Ordered_list_rte','y'),(8,'Underline','Underline_rte','y'),(9,'Unordered List','Unordered_list_rte','y'),(10,'View Source','View_source_rte','y');
/*!40000 ALTER TABLE `exp_rte_tools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_rte_toolsets`
--

DROP TABLE IF EXISTS `exp_rte_toolsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_rte_toolsets` (
  `toolset_id` int(10) unsigned NOT NULL auto_increment,
  `member_id` int(10) default '0',
  `name` varchar(100) default NULL,
  `tools` text,
  `enabled` char(1) default 'y',
  PRIMARY KEY  (`toolset_id`),
  KEY `member_id` (`member_id`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_rte_toolsets`
--

LOCK TABLES `exp_rte_toolsets` WRITE;
/*!40000 ALTER TABLE `exp_rte_toolsets` DISABLE KEYS */;
INSERT INTO `exp_rte_toolsets` VALUES (1,0,'Default','3|2|5|1|9|7|6|4|10','y');
/*!40000 ALTER TABLE `exp_rte_toolsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_search`
--

DROP TABLE IF EXISTS `exp_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_search` (
  `search_id` varchar(32) NOT NULL,
  `site_id` int(4) NOT NULL default '1',
  `search_date` int(10) NOT NULL,
  `keywords` varchar(60) NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `total_results` int(6) NOT NULL,
  `per_page` tinyint(3) unsigned NOT NULL,
  `query` mediumtext,
  `custom_fields` mediumtext,
  `result_page` varchar(70) NOT NULL,
  PRIMARY KEY  (`search_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_search`
--

LOCK TABLES `exp_search` WRITE;
/*!40000 ALTER TABLE `exp_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_search_log`
--

DROP TABLE IF EXISTS `exp_search_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_search_log` (
  `id` int(10) NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `member_id` int(10) unsigned NOT NULL,
  `screen_name` varchar(50) NOT NULL,
  `ip_address` varchar(45) NOT NULL default '0',
  `search_date` int(10) NOT NULL,
  `search_type` varchar(32) NOT NULL,
  `search_terms` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_search_log`
--

LOCK TABLES `exp_search_log` WRITE;
/*!40000 ALTER TABLE `exp_search_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_search_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_security_hashes`
--

DROP TABLE IF EXISTS `exp_security_hashes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_security_hashes` (
  `hash_id` int(10) unsigned NOT NULL auto_increment,
  `date` int(10) unsigned NOT NULL,
  `session_id` varchar(40) NOT NULL default '0',
  `hash` varchar(40) NOT NULL,
  PRIMARY KEY  (`hash_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=2142 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_security_hashes`
--

LOCK TABLES `exp_security_hashes` WRITE;
/*!40000 ALTER TABLE `exp_security_hashes` DISABLE KEYS */;
INSERT INTO `exp_security_hashes` VALUES (2103,1371506118,'e01c97389b335147b4753a8655e8c73b1a26fcfd','57c4a6b8e11a5c92d65fb35be7f9cb285c404c07'),(2104,1371506118,'e01c97389b335147b4753a8655e8c73b1a26fcfd','98a460c4e60624be439c03f55056b26481e6d689'),(2105,1371506118,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ea1c89eea4bd4ed10fb5df6ed5b7e23ddc24aa9c'),(2122,1371506542,'e01c97389b335147b4753a8655e8c73b1a26fcfd','0cef4a8902ab46d466b2ea46449bc3d15af20fc6'),(2123,1371506542,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ede4aa31783267b4febfd1f9abfb93ac50a81135'),(2124,1371506550,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ca904a3c5cd843b65613d60aa8730a41bf6304e4'),(2125,1371506550,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ca60c3fb63ce26db1ae12e9049d18c48e9ace898'),(2127,1371506615,'e01c97389b335147b4753a8655e8c73b1a26fcfd','19077e537c42747fa3ea18f518ba318506062a64'),(2128,1371506615,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b3fa329f2afd7fff52624322e85a1e3cb8f57e17'),(2129,1371506617,'e01c97389b335147b4753a8655e8c73b1a26fcfd','99099400a83db9983bcfb80981520e359fa6c232'),(2130,1371506617,'e01c97389b335147b4753a8655e8c73b1a26fcfd','7481f026705bbe9c048713398711edbfb98c8051'),(2131,1371507216,'0','66ab1cd45e454110ce5e60c69554474e1793c00f'),(2133,1371507219,'0','1b91414f8b55832113e90fdb982ee1249fa88317'),(2134,1371507219,'b12b89c27c6336d352f2225e5151a349b4243dd8','5c168a213ac24377d5ab65269d2dbec893f75168'),(2135,1371507221,'b12b89c27c6336d352f2225e5151a349b4243dd8','f3c05d17c3913ad256ab2198c98aa96ccccd7b9f'),(2140,1371507246,'b12b89c27c6336d352f2225e5151a349b4243dd8','6ff1751b1b79b42a080789aba823d6feb4e7205e'),(2137,1371507229,'b12b89c27c6336d352f2225e5151a349b4243dd8','75998dbbc0665269112fbdfaeeca64d98dffa8b1'),(2138,1371507229,'b12b89c27c6336d352f2225e5151a349b4243dd8','509d44923567790d9739c3ba3790ea53ad6c5d93'),(2139,1371507229,'b12b89c27c6336d352f2225e5151a349b4243dd8','dd845fcede095bb9fdd719eb6e000cf7804edf80'),(2141,1371507246,'b12b89c27c6336d352f2225e5151a349b4243dd8','ff0e56bdb48cd8e68255d75b43bcf8d5e4cc62bf'),(2096,1371506057,'e01c97389b335147b4753a8655e8c73b1a26fcfd','6fc777d0c7cce5d04ae24d8f125fe32600030da9'),(2097,1371506057,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4de82ed6e7463d74ba75b23febf7149584de4b60'),(2098,1371506058,'e01c97389b335147b4753a8655e8c73b1a26fcfd','12480bca25abbce624e749bf72a04c1d6e00e611'),(2100,1371506069,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d044fa39e9e3cdddfb51ef18dbf7a79ff89ebb23'),(2101,1371506076,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ece2a9a98bb8c9345439a522184aee43d309b2ee'),(2106,1371506176,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c02c420aa976c22eeee193d2c40ae64170617b7b'),(2107,1371506176,'e01c97389b335147b4753a8655e8c73b1a26fcfd','77c274f0043077c1a36ae9e0371424b94af83f17'),(2112,1371506205,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f2ac804752e90b1aa93cca92df39c5fcfa98b490'),(2109,1371506191,'e01c97389b335147b4753a8655e8c73b1a26fcfd','8fc7e98aa1584f72cb1aee1ec8f4531ab74aca4c'),(2110,1371506191,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4411ccf775ed77f993c9fb4875d5da03b40d7724'),(2111,1371506191,'e01c97389b335147b4753a8655e8c73b1a26fcfd','2320778c3f7183a60e1d51d088d1d03ba48f07da'),(2113,1371506205,'e01c97389b335147b4753a8655e8c73b1a26fcfd','75995148f8c37a70825ea465c98a67a8097177af'),(2118,1371506227,'e01c97389b335147b4753a8655e8c73b1a26fcfd','84ce3f77721b84fb63510c7cc9a1499fef34b792'),(2115,1371506216,'e01c97389b335147b4753a8655e8c73b1a26fcfd','990110298fa89bb735db3e13e203d55d3136d39c'),(2116,1371506216,'e01c97389b335147b4753a8655e8c73b1a26fcfd','dee73ac4c97c18b69c40cb60b4d0fc349aa88de9'),(2117,1371506216,'e01c97389b335147b4753a8655e8c73b1a26fcfd','708fec76307655d08790a7396afe0c9740db00f2'),(2119,1371506227,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ba1e7f7f46a9a6e0857300129eabcfb05b79c7b8'),(2120,1371506523,'e01c97389b335147b4753a8655e8c73b1a26fcfd','00159e0ca8ee4bce7ec2df0340df35504efc6b41'),(2121,1371506541,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f4a663a28d2de0ee6244a97873549de897a15db2'),(2099,1371506069,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ed7cc63b6dc5d30e14f61f259b4ffcadb9146709'),(2094,1371506052,'e01c97389b335147b4753a8655e8c73b1a26fcfd','85dfcafb51fd5589e4bfc52bc60dcb27c9323da6'),(2093,1371506019,'e01c97389b335147b4753a8655e8c73b1a26fcfd','277366525611dd33989a4d42fa74e9274ccb7b04'),(2092,1371506019,'e01c97389b335147b4753a8655e8c73b1a26fcfd','664250626f198a73e891279acb923c5c21fd4baf'),(2086,1371505994,'e01c97389b335147b4753a8655e8c73b1a26fcfd','761d5c6ea252ccf3e7461a802d9b1af8f3212926'),(2087,1371505997,'e01c97389b335147b4753a8655e8c73b1a26fcfd','30e57ef34d3372600231c6733f67e090a2462061'),(2088,1371505997,'e01c97389b335147b4753a8655e8c73b1a26fcfd','26115d78722043551603962db46eb369179f2700'),(2090,1371506018,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d861220d81f76d1670b08f78e83cad895b11b40a'),(2091,1371506018,'e01c97389b335147b4753a8655e8c73b1a26fcfd','17e6936f239b243a15e09f6845d0561dbe4db52f'),(2085,1371505984,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c4e5caaf7c7f325c645f73bf0f0dacea74b6af01'),(2084,1371505975,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3d15eb259ef191a67f5ab0972e02bd1983e2fc4e'),(2083,1371505975,'e01c97389b335147b4753a8655e8c73b1a26fcfd','7e1cde6fc659b103183859feb9116324bceb4d64'),(2081,1371505974,'e01c97389b335147b4753a8655e8c73b1a26fcfd','efaa55b6ed1f0f074a0e21a25c13427d561b5c22'),(2079,1371505938,'e01c97389b335147b4753a8655e8c73b1a26fcfd','37cd940f0a66a84f08ec41ec7be79266b0ee0632'),(2082,1371505975,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c900a6399cfdeb7b2390b0c8aa17a3553f2bb66b'),(2078,1371505938,'e01c97389b335147b4753a8655e8c73b1a26fcfd','05e101c2a37081dc8446f2ab0549f721808ad77f'),(2077,1371505935,'e01c97389b335147b4753a8655e8c73b1a26fcfd','21b2d5652ab32136d5b701063b7d89516d50b09d'),(2076,1371505935,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f0bb45e70df0bc3a5b8d58842757144a746f44e8'),(2075,1371505935,'e01c97389b335147b4753a8655e8c73b1a26fcfd','6e043c967510a53010cc3b416d9ec527aeb5f295'),(2074,1371505882,'e01c97389b335147b4753a8655e8c73b1a26fcfd','bb1c409b3b33b0b298d758cd7f19e07f6e577d44'),(2073,1371505880,'e01c97389b335147b4753a8655e8c73b1a26fcfd','16b0b484f0c38d47e7c49d424b8416a894ed0e8a'),(2071,1371505871,'e01c97389b335147b4753a8655e8c73b1a26fcfd','85c93d9195e271d4ad85560af2bb49eef8c29650'),(2070,1371505871,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4100b6ec2d2f1d652c4a77fda097a11f209ea1a4'),(2069,1371505871,'e01c97389b335147b4753a8655e8c73b1a26fcfd','aad09c76cf7b11db3387e5afe3ad7c8150f14e74'),(2072,1371505880,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3dc627a0e2f403ac9af6bdbbffa901023e8a6911'),(2067,1371505864,'e01c97389b335147b4753a8655e8c73b1a26fcfd','224173a0a3b24651fcccd59ad35621464a6ee4b4'),(2066,1371505862,'e01c97389b335147b4753a8655e8c73b1a26fcfd','0ce05f1941f9987d91b77f5f88df5e64d4ad9363'),(2064,1371505858,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d0283a62965af5394efe99458db1e2daecd9cb5d'),(2063,1371505858,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d6b2b3a1dad9a284daf2500de76129d4f4c67344'),(2062,1371505857,'e01c97389b335147b4753a8655e8c73b1a26fcfd','cb152333bc253379505a578181fec58c361d03de'),(2065,1371505861,'e01c97389b335147b4753a8655e8c73b1a26fcfd','9ea724de2c322ee1f8e277955c1aeda22203ddbb'),(2060,1371505853,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4719bf357395b431fec36fead3b4410a9d63873d'),(2059,1371505848,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c6ea39d8086c0847305ac0a306f08dabb773bb1c'),(2057,1371505843,'e01c97389b335147b4753a8655e8c73b1a26fcfd','0f6ceef47863ebd58789372815c577afff81a5d6'),(2056,1371505843,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ba899c52243382c232621465103d2eaf5bea16c9'),(2055,1371505843,'e01c97389b335147b4753a8655e8c73b1a26fcfd','84e2f59441d65e0448bde5b4ef72074c1ba8c617'),(2058,1371505848,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e597744d9d369f086af1e2de6bc586acd003ddb4'),(2053,1371505837,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f0d31b41610e5363e7b4f31140f39c0a91343280'),(2052,1371505832,'e01c97389b335147b4753a8655e8c73b1a26fcfd','918bcd52b9021bcc25af5bdc942a8c597e5f0ba0'),(2050,1371505826,'e01c97389b335147b4753a8655e8c73b1a26fcfd','052e7887cca0ad2ea5bb7c085d99e9aa1f77d945'),(2049,1371505825,'e01c97389b335147b4753a8655e8c73b1a26fcfd','1113d168f84c05205f8e34b0a8f742759a98d741'),(2048,1371505825,'e01c97389b335147b4753a8655e8c73b1a26fcfd','538ca413f01c5a5de993e11ed4147b18f3c1202a'),(2051,1371505832,'e01c97389b335147b4753a8655e8c73b1a26fcfd','90421a4fbcc5fa9fd8a64f13f919873593701b10'),(2046,1371505820,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4550feb5a659b005854830ef2e4ff21c3b789bea'),(2045,1371505820,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3821e9006f2bf65ff12697cb44acf91d7326cfec'),(2044,1371505820,'e01c97389b335147b4753a8655e8c73b1a26fcfd','328292731d37cb6f5d92c6afbddfe0bc83b3d7c6'),(2043,1371505819,'e01c97389b335147b4753a8655e8c73b1a26fcfd','8d050ed2a5123963d6ae6903b53da20aed06fd36'),(2042,1371505804,'e01c97389b335147b4753a8655e8c73b1a26fcfd','995397e77e63a05a0e91125f814c87df55a52b01'),(2041,1371505802,'e01c97389b335147b4753a8655e8c73b1a26fcfd','bc9441785cabf26f2b610c5554a4f447d58472cc'),(2040,1371505802,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ae95d048594fce6dcfbc85cba015227dc091aa39'),(2039,1371505798,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3ad8941a0a1059b3f6e743586b245872c30b01c1'),(2038,1371505796,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b0f6838dea67dd70f5b380704c8d5dadd3603f13'),(2037,1371505784,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c8d6e9c3ca1370c06224749d28fabd9f8661d0ac'),(2036,1371505775,'e01c97389b335147b4753a8655e8c73b1a26fcfd','0c40c6fb554cbd0a8f786f3116dab5d970bd63e6'),(2035,1371505736,'e01c97389b335147b4753a8655e8c73b1a26fcfd','62241265ca0b80b19891893b1c360ba650673a93'),(2034,1371505736,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4d75bdc8d78a52d6bc193f18288a3113fe7cea86'),(2033,1371505715,'e01c97389b335147b4753a8655e8c73b1a26fcfd','7713ced5f343c64cd10a38e06757831adeaba92e'),(2031,1371505699,'e01c97389b335147b4753a8655e8c73b1a26fcfd','83c95948102557be6f7cc5008845d77bcd416f1e'),(2030,1371505699,'e01c97389b335147b4753a8655e8c73b1a26fcfd','21f204b9a323e94891a16fccf43a2fcfde747122'),(2029,1371505698,'e01c97389b335147b4753a8655e8c73b1a26fcfd','55a50dd6332d32ed6e87f410cdd51fc4947a4490'),(2032,1371505715,'e01c97389b335147b4753a8655e8c73b1a26fcfd','7efdaa3717587aae3fc6be46da5826af86789f38'),(2027,1371505692,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d64f87ea712d04c32c6825214ee1b4d3126298c8'),(2026,1371505689,'e01c97389b335147b4753a8655e8c73b1a26fcfd','5be91adb88ba161aac6e37bd06b378903d0cf8b8'),(2025,1371505614,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e800059fabc6c0790b47a26aef0b54795fc35b6a'),(2024,1371505614,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3413043a4b518f40f064cb94d6b0fd8fecbfc8e9'),(2023,1371505612,'e01c97389b335147b4753a8655e8c73b1a26fcfd','28885620e005a17c2b3ffde6e930ee86467e41be'),(2022,1371505612,'e01c97389b335147b4753a8655e8c73b1a26fcfd','297975223ffaab6ddb81ad46eefcbd6fc34748a2'),(2021,1371505611,'e01c97389b335147b4753a8655e8c73b1a26fcfd','49e07232357272441f1835469460b437423e6ba9'),(2020,1371505611,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c52484f4cc2d73d4d1938743d440397078fd3f9e'),(2018,1371505545,'e01c97389b335147b4753a8655e8c73b1a26fcfd','9fcbb8d7553661ec850fc6966a311c235c9b9592'),(2017,1371505545,'e01c97389b335147b4753a8655e8c73b1a26fcfd','57962907bc83b7761685366d2c34cf3bb4f5b076'),(2016,1371505541,'e01c97389b335147b4753a8655e8c73b1a26fcfd','2bad0901482c8ec2b7a3bca1d7ab829c77c68fd8'),(2015,1371505541,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b8dc600be30ec561cc33930f4c6690be672d2681'),(2014,1371505540,'e01c97389b335147b4753a8655e8c73b1a26fcfd','aa39f9fac3b7740202bf690464c3b90ada4570cf'),(2013,1371505540,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b6f5191212ebc69d7aa85909bc8e20885f3fc2ae'),(2011,1371505487,'e01c97389b335147b4753a8655e8c73b1a26fcfd','5e421f218f0883c97b0cd0e79d700638557ed3de'),(2010,1371505487,'e01c97389b335147b4753a8655e8c73b1a26fcfd','2ee46e92320d773f1cdb22a4177ed23a93279336'),(2009,1371505464,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f482dfc2ed36b2101778bbc5f65026c302df1a35'),(2008,1371505426,'e01c97389b335147b4753a8655e8c73b1a26fcfd','6d14661ee56729cdd92132b03c32c573d6d24fde'),(2007,1371505426,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e26ae6417916ab70820858c6386cdc752e5584d8'),(2006,1371505424,'e01c97389b335147b4753a8655e8c73b1a26fcfd','752cb2489d37d68c9041f8c49ed4051bc1dfe0bd'),(2005,1371505424,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f3a5d308c0d3f494db6ad5be0fd7da7a15dad141'),(2003,1371505407,'e01c97389b335147b4753a8655e8c73b1a26fcfd','7381d25ed4b3b8a1cb63cd07b59db12374b5a56f'),(2002,1371505402,'e01c97389b335147b4753a8655e8c73b1a26fcfd','2203b93012d179221b76e53c9b959598dad9cc72'),(2001,1371505290,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b00d9b75bf2bd78f464cd930d3bf101cfc9ddf51'),(2000,1371505289,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e3e94f6e6a9a1b034d02b144758ceca4bcd26866'),(1999,1371505288,'e01c97389b335147b4753a8655e8c73b1a26fcfd','8e4d6273026a12b1a6b1a004d4cfb1dbd3c27745'),(1998,1371505288,'e01c97389b335147b4753a8655e8c73b1a26fcfd','5e628aa940b0d2178bd7109e741b1d1063bcb656'),(1996,1371505258,'e01c97389b335147b4753a8655e8c73b1a26fcfd','beb31ef3528bee893d1909beda5e50a65abf2fc0'),(1995,1371505258,'e01c97389b335147b4753a8655e8c73b1a26fcfd','a1f7c37828363c101483cbb7f1ec78c19ae4b57e'),(1994,1371505229,'e01c97389b335147b4753a8655e8c73b1a26fcfd','560555babb3e12dd7d7e20aa949ce9f2bef38f34'),(1993,1371505229,'e01c97389b335147b4753a8655e8c73b1a26fcfd','708fe1b32797a8d3d419bc6d49544f881476cb55'),(1992,1371505215,'e01c97389b335147b4753a8655e8c73b1a26fcfd','11558a4c83e7bf5331690bec0f89e6982ca5c12a'),(1991,1371505215,'e01c97389b335147b4753a8655e8c73b1a26fcfd','1ba0850ee2244b347ad1a44a3fdd2c969c9e4c4d'),(1990,1371505214,'e01c97389b335147b4753a8655e8c73b1a26fcfd','62d8e85a0fde83c367171c96cedb13f49bec0069'),(1989,1371505214,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3b79fccc28b2c2e2b844ca0173e61aa0c2541b90'),(1987,1371505192,'e01c97389b335147b4753a8655e8c73b1a26fcfd','240cb3bafe6e9f6d894342adc989a05f1432cee5'),(1986,1371505155,'e01c97389b335147b4753a8655e8c73b1a26fcfd','8729f4d71f4e857ff8b27161663cd188183721b3'),(1985,1371505155,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c6c01e4d86d16f5bc171d4a8e4169eb832899069'),(1984,1371505154,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b266d5368737f483c3356dcd5fbd2610bc0cc3e7'),(1983,1371505154,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3c067b1dfc37c5aa64f7f4c34bdb2261c9cfe6a2'),(1981,1371505134,'e01c97389b335147b4753a8655e8c73b1a26fcfd','cbf5c634826b318acb8f7a8e8a50d141c543cc9b'),(1980,1371505133,'e01c97389b335147b4753a8655e8c73b1a26fcfd','dd140b2de2b503f6d0f99886b975e99e778dd20c'),(1979,1371505133,'e01c97389b335147b4753a8655e8c73b1a26fcfd','222ef1a86af5bfa0812381f0daaab8dfb44d4acc'),(1978,1371505133,'e01c97389b335147b4753a8655e8c73b1a26fcfd','eec954348aab8bd708d7eb637af7b698dc131d54'),(1976,1371505082,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b979afed5058d1369b25f4ad1311e4a6ecfe2157'),(1975,1371505082,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d27572c6756f447a7f909fafe8990cbf7b01face'),(1974,1371505079,'e01c97389b335147b4753a8655e8c73b1a26fcfd','418088e33b2935e295e4368dc05cba1b75ae46f0'),(1973,1371505078,'e01c97389b335147b4753a8655e8c73b1a26fcfd','9af6f3f0d842115f1c7dc79eded9ff75c2863ee3'),(1972,1371505077,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b840c8fdb2e7c177eaf7cce045d279eab0cfef3d'),(1971,1371505077,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e9017a92903577153daf8f1c7bfa3b040a76f369'),(1969,1371505052,'e01c97389b335147b4753a8655e8c73b1a26fcfd','671cb4ebbe4442730c9970d3a8b52f0be4f38a85'),(1968,1371505052,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ec1495ab376bc3b90809cfb945807c2a6dd67746'),(1967,1371505046,'e01c97389b335147b4753a8655e8c73b1a26fcfd','d95e32940fe60eca2b3f8e4c459408b52558441c'),(1966,1371505046,'e01c97389b335147b4753a8655e8c73b1a26fcfd','6b866aa55ce956567e608921cd41109f8a054457'),(1965,1371505045,'e01c97389b335147b4753a8655e8c73b1a26fcfd','aeb1967be63e0666cda47cff8d36f854049e48ac'),(1964,1371504992,'e01c97389b335147b4753a8655e8c73b1a26fcfd','b9b140448205dffd82d8e637773a1c02e2c69fa6'),(1963,1371504989,'e01c97389b335147b4753a8655e8c73b1a26fcfd','8f76ea545d20b0944d587763436ed3d3f5d8de9d'),(1962,1371504946,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c9a3c92f7d7a2eb344d5217e07a5de8e4adbae11'),(1960,1371504910,'e01c97389b335147b4753a8655e8c73b1a26fcfd','9b3e6682c2eb6cd37df482aa6e232185cbea875e'),(1959,1371504909,'e01c97389b335147b4753a8655e8c73b1a26fcfd','0fe27d4e140710548abee90d94f584299235bce1'),(1958,1371504909,'e01c97389b335147b4753a8655e8c73b1a26fcfd','99860b8cf94107688b5954cde22ed4d52af0ca35'),(1961,1371504946,'e01c97389b335147b4753a8655e8c73b1a26fcfd','51994a7542a59ae790f0d1f5ed2b237789d5bba3'),(1956,1371504895,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e99aa04bb3a9e8a4b31029cf9f9dbeb8d7a34c1b'),(1955,1371504893,'e01c97389b335147b4753a8655e8c73b1a26fcfd','e0add8e15d96a7cf0d41bb5cd9db325acf65ddea'),(1954,1371504852,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4e91af8dced626336fb3a2fbfc490c857ae316b5'),(1952,1371504843,'e01c97389b335147b4753a8655e8c73b1a26fcfd','3c379364dbe01090ca926e9b4e41f696f5e01424'),(1951,1371504843,'e01c97389b335147b4753a8655e8c73b1a26fcfd','c29ef10d03adcebdf140a77e884e3a0c0a4be264'),(1950,1371504843,'e01c97389b335147b4753a8655e8c73b1a26fcfd','062e5322765fec89283e1c2bd240e572434740b2'),(1953,1371504851,'e01c97389b335147b4753a8655e8c73b1a26fcfd','4147512adfb21d9ae99445823f19e8f725bfa67a'),(1948,1371504802,'e01c97389b335147b4753a8655e8c73b1a26fcfd','ccecee9085d12f9993eb4d1e92bdbff6c3699fd2'),(1946,1371504799,'e01c97389b335147b4753a8655e8c73b1a26fcfd','487bb8229efeff1c7fd77abbdb7489898f7cd104'),(1945,1371504720,'e01c97389b335147b4753a8655e8c73b1a26fcfd','6db38d46627bc6ea2f60eb1b0ba292bd60f2b71a'),(1944,1371504720,'e01c97389b335147b4753a8655e8c73b1a26fcfd','aad005e97718666f84c122bd2b45ea194aa1fb31'),(1943,1371504719,'e01c97389b335147b4753a8655e8c73b1a26fcfd','17f7ad92f90df7635db9ddc127847ef1344060ca'),(1947,1371504802,'e01c97389b335147b4753a8655e8c73b1a26fcfd','838f8035cd21e12d2671e823f996e8fe4ac5f9e4'),(1941,1371504680,'e01c97389b335147b4753a8655e8c73b1a26fcfd','08ed70302001b2c34a9dc566bba403b87b387a0e'),(1940,1371504667,'e01c97389b335147b4753a8655e8c73b1a26fcfd','f83e2997e29f7b6ed8e63e8a7e761bae60b6da05'),(1939,1371504667,'0','88ed3c8221cd7d587fea4b51416779eab55956b9');
/*!40000 ALTER TABLE `exp_security_hashes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_sessions`
--

DROP TABLE IF EXISTS `exp_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `member_id` int(10) NOT NULL default '0',
  `admin_sess` tinyint(1) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `fingerprint` varchar(40) NOT NULL,
  `sess_start` int(10) unsigned NOT NULL default '0',
  `last_activity` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`session_id`),
  KEY `member_id` (`member_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_sessions`
--

LOCK TABLES `exp_sessions` WRITE;
/*!40000 ALTER TABLE `exp_sessions` DISABLE KEYS */;
INSERT INTO `exp_sessions` VALUES ('e01c97389b335147b4753a8655e8c73b1a26fcfd',1,1,'107.202.218.108','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:21.0) Gecko/20100101 Firefox/21.0','aa0582454a67ed7e617551e24898605a',1371504667,1371507281),('b12b89c27c6336d352f2225e5151a349b4243dd8',1,1,'24.155.109.33','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36','42550eae14f88696429272cebf338793',1371507219,1371507247);
/*!40000 ALTER TABLE `exp_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_sites`
--

DROP TABLE IF EXISTS `exp_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_sites` (
  `site_id` int(5) unsigned NOT NULL auto_increment,
  `site_label` varchar(100) NOT NULL default '',
  `site_name` varchar(50) NOT NULL default '',
  `site_description` text,
  `site_system_preferences` mediumtext NOT NULL,
  `site_mailinglist_preferences` text NOT NULL,
  `site_member_preferences` text NOT NULL,
  `site_template_preferences` text NOT NULL,
  `site_channel_preferences` text NOT NULL,
  `site_bootstrap_checksums` text NOT NULL,
  `site_pages` text NOT NULL,
  PRIMARY KEY  (`site_id`),
  KEY `site_name` (`site_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_sites`
--

LOCK TABLES `exp_sites` WRITE;
/*!40000 ALTER TABLE `exp_sites` DISABLE KEYS */;
INSERT INTO `exp_sites` VALUES (1,'benchmark','default_site',NULL,'YTo5MDp7czoxMDoic2l0ZV9pbmRleCI7czo5OiJpbmRleC5waHAiO3M6ODoic2l0ZV91cmwiO3M6MTg6Imh0dHA6Ly9ub21yYWwuY29tLyI7czoxNjoidGhlbWVfZm9sZGVyX3VybCI7czoyNToiaHR0cDovL25vbXJhbC5jb20vdGhlbWVzLyI7czoxNToid2VibWFzdGVyX2VtYWlsIjtzOjE5OiJqb3Jkb3RlY2hAZ21haWwuY29tIjtzOjE0OiJ3ZWJtYXN0ZXJfbmFtZSI7czowOiIiO3M6MjA6ImNoYW5uZWxfbm9tZW5jbGF0dXJlIjtzOjc6ImNoYW5uZWwiO3M6MTA6Im1heF9jYWNoZXMiO3M6MzoiMTUwIjtzOjExOiJjYXB0Y2hhX3VybCI7czozNDoiaHR0cDovL25vbXJhbC5jb20vaW1hZ2VzL2NhcHRjaGFzLyI7czoxMjoiY2FwdGNoYV9wYXRoIjtzOjQ2OiIvaG9tZS9qb3Jkb3RlY2gvd2ViYXBwcy9iZW5jaC9pbWFnZXMvY2FwdGNoYXMvIjtzOjEyOiJjYXB0Y2hhX2ZvbnQiO3M6MToieSI7czoxMjoiY2FwdGNoYV9yYW5kIjtzOjE6InkiO3M6MjM6ImNhcHRjaGFfcmVxdWlyZV9tZW1iZXJzIjtzOjE6Im4iO3M6MTc6ImVuYWJsZV9kYl9jYWNoaW5nIjtzOjE6Im4iO3M6MTg6ImVuYWJsZV9zcWxfY2FjaGluZyI7czoxOiJuIjtzOjE4OiJmb3JjZV9xdWVyeV9zdHJpbmciO3M6MToibiI7czoxMzoic2hvd19wcm9maWxlciI7czoxOiJuIjtzOjE4OiJ0ZW1wbGF0ZV9kZWJ1Z2dpbmciO3M6MToibiI7czoxNToiaW5jbHVkZV9zZWNvbmRzIjtzOjE6Im4iO3M6MTM6ImNvb2tpZV9kb21haW4iO3M6MDoiIjtzOjExOiJjb29raWVfcGF0aCI7czowOiIiO3M6MTc6InVzZXJfc2Vzc2lvbl90eXBlIjtzOjE6ImMiO3M6MTg6ImFkbWluX3Nlc3Npb25fdHlwZSI7czoyOiJjcyI7czoyMToiYWxsb3dfdXNlcm5hbWVfY2hhbmdlIjtzOjE6InkiO3M6MTg6ImFsbG93X211bHRpX2xvZ2lucyI7czoxOiJ5IjtzOjE2OiJwYXNzd29yZF9sb2Nrb3V0IjtzOjE6InkiO3M6MjU6InBhc3N3b3JkX2xvY2tvdXRfaW50ZXJ2YWwiO3M6MToiMSI7czoyMDoicmVxdWlyZV9pcF9mb3JfbG9naW4iO3M6MToieSI7czoyMjoicmVxdWlyZV9pcF9mb3JfcG9zdGluZyI7czoxOiJ5IjtzOjI0OiJyZXF1aXJlX3NlY3VyZV9wYXNzd29yZHMiO3M6MToibiI7czoxOToiYWxsb3dfZGljdGlvbmFyeV9wdyI7czoxOiJ5IjtzOjIzOiJuYW1lX29mX2RpY3Rpb25hcnlfZmlsZSI7czowOiIiO3M6MTc6Inhzc19jbGVhbl91cGxvYWRzIjtzOjE6InkiO3M6MTU6InJlZGlyZWN0X21ldGhvZCI7czo4OiJyZWRpcmVjdCI7czo5OiJkZWZ0X2xhbmciO3M6NzoiZW5nbGlzaCI7czo4OiJ4bWxfbGFuZyI7czoyOiJlbiI7czoxMjoic2VuZF9oZWFkZXJzIjtzOjE6InkiO3M6MTE6Imd6aXBfb3V0cHV0IjtzOjE6Im4iO3M6MTM6ImxvZ19yZWZlcnJlcnMiO3M6MToieSI7czoxMzoibWF4X3JlZmVycmVycyI7czozOiI1MDAiO3M6MTE6InRpbWVfZm9ybWF0IjtzOjI6InVzIjtzOjE1OiJzZXJ2ZXJfdGltZXpvbmUiO3M6MTU6IkFtZXJpY2EvQ2hpY2FnbyI7czoxMzoic2VydmVyX29mZnNldCI7czowOiIiO3M6MjE6ImRlZmF1bHRfc2l0ZV90aW1lem9uZSI7czoxNToiQW1lcmljYS9DaGljYWdvIjtzOjE1OiJob25vcl9lbnRyeV9kc3QiO3M6MToieSI7czoxMzoibWFpbF9wcm90b2NvbCI7czo0OiJtYWlsIjtzOjExOiJzbXRwX3NlcnZlciI7czowOiIiO3M6MTM6InNtdHBfdXNlcm5hbWUiO3M6MDoiIjtzOjEzOiJzbXRwX3Bhc3N3b3JkIjtzOjA6IiI7czoxMToiZW1haWxfZGVidWciO3M6MToibiI7czoxMzoiZW1haWxfY2hhcnNldCI7czo1OiJ1dGYtOCI7czoxNToiZW1haWxfYmF0Y2htb2RlIjtzOjE6Im4iO3M6MTY6ImVtYWlsX2JhdGNoX3NpemUiO3M6MDoiIjtzOjExOiJtYWlsX2Zvcm1hdCI7czo1OiJwbGFpbiI7czo5OiJ3b3JkX3dyYXAiO3M6MToieSI7czoyMjoiZW1haWxfY29uc29sZV90aW1lbG9jayI7czoxOiI1IjtzOjIyOiJsb2dfZW1haWxfY29uc29sZV9tc2dzIjtzOjE6InkiO3M6ODoiY3BfdGhlbWUiO3M6NzoiZGVmYXVsdCI7czoyMToiZW1haWxfbW9kdWxlX2NhcHRjaGFzIjtzOjE6Im4iO3M6MTY6ImxvZ19zZWFyY2hfdGVybXMiO3M6MToieSI7czoxMjoic2VjdXJlX2Zvcm1zIjtzOjE6InkiO3M6MTk6ImRlbnlfZHVwbGljYXRlX2RhdGEiO3M6MToieSI7czoyNDoicmVkaXJlY3Rfc3VibWl0dGVkX2xpbmtzIjtzOjE6Im4iO3M6MTY6ImVuYWJsZV9jZW5zb3JpbmciO3M6MToibiI7czoxNDoiY2Vuc29yZWRfd29yZHMiO3M6MDoiIjtzOjE4OiJjZW5zb3JfcmVwbGFjZW1lbnQiO3M6MDoiIjtzOjEwOiJiYW5uZWRfaXBzIjtzOjA6IiI7czoxMzoiYmFubmVkX2VtYWlscyI7czowOiIiO3M6MTY6ImJhbm5lZF91c2VybmFtZXMiO3M6MDoiIjtzOjE5OiJiYW5uZWRfc2NyZWVuX25hbWVzIjtzOjA6IiI7czoxMDoiYmFuX2FjdGlvbiI7czo4OiJyZXN0cmljdCI7czoxMToiYmFuX21lc3NhZ2UiO3M6MzQ6IlRoaXMgc2l0ZSBpcyBjdXJyZW50bHkgdW5hdmFpbGFibGUiO3M6MTU6ImJhbl9kZXN0aW5hdGlvbiI7czoyMToiaHR0cDovL3d3dy55YWhvby5jb20vIjtzOjE2OiJlbmFibGVfZW1vdGljb25zIjtzOjE6InkiO3M6MTI6ImVtb3RpY29uX3VybCI7czozNzoiaHR0cDovL2JlbmNobG9jYWwuY29tL2ltYWdlcy9zbWlsZXlzLyI7czoxOToicmVjb3VudF9iYXRjaF90b3RhbCI7czo0OiIxMDAwIjtzOjE3OiJuZXdfdmVyc2lvbl9jaGVjayI7czoxOiJ5IjtzOjE3OiJlbmFibGVfdGhyb3R0bGluZyI7czoxOiJuIjtzOjE3OiJiYW5pc2hfbWFza2VkX2lwcyI7czoxOiJ5IjtzOjE0OiJtYXhfcGFnZV9sb2FkcyI7czoyOiIxMCI7czoxMzoidGltZV9pbnRlcnZhbCI7czoxOiI4IjtzOjEyOiJsb2Nrb3V0X3RpbWUiO3M6MjoiMzAiO3M6MTU6ImJhbmlzaG1lbnRfdHlwZSI7czo3OiJtZXNzYWdlIjtzOjE0OiJiYW5pc2htZW50X3VybCI7czowOiIiO3M6MTg6ImJhbmlzaG1lbnRfbWVzc2FnZSI7czo1MDoiWW91IGhhdmUgZXhjZWVkZWQgdGhlIGFsbG93ZWQgcGFnZSBsb2FkIGZyZXF1ZW5jeS4iO3M6MTc6ImVuYWJsZV9zZWFyY2hfbG9nIjtzOjE6InkiO3M6MTk6Im1heF9sb2dnZWRfc2VhcmNoZXMiO3M6MzoiNTAwIjtzOjE3OiJ0aGVtZV9mb2xkZXJfcGF0aCI7czozNzoiL2hvbWUvam9yZG90ZWNoL3dlYmFwcHMvYmVuY2gvdGhlbWVzLyI7czoxMDoiaXNfc2l0ZV9vbiI7czoxOiJ5IjtzOjExOiJydGVfZW5hYmxlZCI7czoxOiJ5IjtzOjIyOiJydGVfZGVmYXVsdF90b29sc2V0X2lkIjtzOjE6IjEiO30=','YTozOntzOjE5OiJtYWlsaW5nbGlzdF9lbmFibGVkIjtzOjE6InkiO3M6MTg6Im1haWxpbmdsaXN0X25vdGlmeSI7czoxOiJuIjtzOjI1OiJtYWlsaW5nbGlzdF9ub3RpZnlfZW1haWxzIjtzOjA6IiI7fQ==','YTo0NDp7czoxMDoidW5fbWluX2xlbiI7czoxOiI0IjtzOjEwOiJwd19taW5fbGVuIjtzOjE6IjUiO3M6MjU6ImFsbG93X21lbWJlcl9yZWdpc3RyYXRpb24iO3M6MToibiI7czoyNToiYWxsb3dfbWVtYmVyX2xvY2FsaXphdGlvbiI7czoxOiJ5IjtzOjE4OiJyZXFfbWJyX2FjdGl2YXRpb24iO3M6NToiZW1haWwiO3M6MjM6Im5ld19tZW1iZXJfbm90aWZpY2F0aW9uIjtzOjE6Im4iO3M6MjM6Im1icl9ub3RpZmljYXRpb25fZW1haWxzIjtzOjA6IiI7czoyNDoicmVxdWlyZV90ZXJtc19vZl9zZXJ2aWNlIjtzOjE6InkiO3M6MjI6InVzZV9tZW1iZXJzaGlwX2NhcHRjaGEiO3M6MToibiI7czoyMDoiZGVmYXVsdF9tZW1iZXJfZ3JvdXAiO3M6MToiNSI7czoxNToicHJvZmlsZV90cmlnZ2VyIjtzOjY6Im1lbWJlciI7czoxMjoibWVtYmVyX3RoZW1lIjtzOjc6ImRlZmF1bHQiO3M6MTQ6ImVuYWJsZV9hdmF0YXJzIjtzOjE6InkiO3M6MjA6ImFsbG93X2F2YXRhcl91cGxvYWRzIjtzOjE6Im4iO3M6MTA6ImF2YXRhcl91cmwiO3M6MzM6Imh0dHA6Ly9ub21yYWwuY29tL2ltYWdlcy9hdmF0YXJzLyI7czoxMToiYXZhdGFyX3BhdGgiO3M6NDU6Ii9ob21lL2pvcmRvdGVjaC93ZWJhcHBzL2JlbmNoL2ltYWdlcy9hdmF0YXJzLyI7czoxNjoiYXZhdGFyX21heF93aWR0aCI7czozOiIxMDAiO3M6MTc6ImF2YXRhcl9tYXhfaGVpZ2h0IjtzOjM6IjEwMCI7czoxMzoiYXZhdGFyX21heF9rYiI7czoyOiI1MCI7czoxMzoiZW5hYmxlX3Bob3RvcyI7czoxOiJuIjtzOjk6InBob3RvX3VybCI7czozOToiaHR0cDovL25vbXJhbC5jb20vaW1hZ2VzL21lbWJlcl9waG90b3MvIjtzOjEwOiJwaG90b19wYXRoIjtzOjUxOiIvaG9tZS9qb3Jkb3RlY2gvd2ViYXBwcy9iZW5jaC9pbWFnZXMvbWVtYmVyX3Bob3Rvcy8iO3M6MTU6InBob3RvX21heF93aWR0aCI7czozOiIxMDAiO3M6MTY6InBob3RvX21heF9oZWlnaHQiO3M6MzoiMTAwIjtzOjEyOiJwaG90b19tYXhfa2IiO3M6MjoiNTAiO3M6MTY6ImFsbG93X3NpZ25hdHVyZXMiO3M6MToieSI7czoxMzoic2lnX21heGxlbmd0aCI7czozOiI1MDAiO3M6MjE6InNpZ19hbGxvd19pbWdfaG90bGluayI7czoxOiJuIjtzOjIwOiJzaWdfYWxsb3dfaW1nX3VwbG9hZCI7czoxOiJuIjtzOjExOiJzaWdfaW1nX3VybCI7czo0NzoiaHR0cDovL25vbXJhbC5jb20vaW1hZ2VzL3NpZ25hdHVyZV9hdHRhY2htZW50cy8iO3M6MTI6InNpZ19pbWdfcGF0aCI7czo1OToiL2hvbWUvam9yZG90ZWNoL3dlYmFwcHMvYmVuY2gvaW1hZ2VzL3NpZ25hdHVyZV9hdHRhY2htZW50cy8iO3M6MTc6InNpZ19pbWdfbWF4X3dpZHRoIjtzOjM6IjQ4MCI7czoxODoic2lnX2ltZ19tYXhfaGVpZ2h0IjtzOjI6IjgwIjtzOjE0OiJzaWdfaW1nX21heF9rYiI7czoyOiIzMCI7czoxOToicHJ2X21zZ191cGxvYWRfcGF0aCI7czo1MjoiL2hvbWUvam9yZG90ZWNoL3dlYmFwcHMvYmVuY2gvaW1hZ2VzL3BtX2F0dGFjaG1lbnRzLyI7czoyMzoicHJ2X21zZ19tYXhfYXR0YWNobWVudHMiO3M6MToiMyI7czoyMjoicHJ2X21zZ19hdHRhY2hfbWF4c2l6ZSI7czozOiIyNTAiO3M6MjA6InBydl9tc2dfYXR0YWNoX3RvdGFsIjtzOjM6IjEwMCI7czoxOToicHJ2X21zZ19odG1sX2Zvcm1hdCI7czo0OiJzYWZlIjtzOjE4OiJwcnZfbXNnX2F1dG9fbGlua3MiO3M6MToieSI7czoxNzoicHJ2X21zZ19tYXhfY2hhcnMiO3M6NDoiNjAwMCI7czoxOToibWVtYmVybGlzdF9vcmRlcl9ieSI7czoxMToidG90YWxfcG9zdHMiO3M6MjE6Im1lbWJlcmxpc3Rfc29ydF9vcmRlciI7czo0OiJkZXNjIjtzOjIwOiJtZW1iZXJsaXN0X3Jvd19saW1pdCI7czoyOiIyMCI7fQ==','YTo2OntzOjExOiJzdHJpY3RfdXJscyI7czoxOiJ5IjtzOjg6InNpdGVfNDA0IjtzOjA6IiI7czoxOToic2F2ZV90bXBsX3JldmlzaW9ucyI7czoxOiJuIjtzOjE4OiJtYXhfdG1wbF9yZXZpc2lvbnMiO3M6MToiNSI7czoxNToic2F2ZV90bXBsX2ZpbGVzIjtzOjE6InkiO3M6MTg6InRtcGxfZmlsZV9iYXNlcGF0aCI7czo2MzoiL2hvbWUvam9yZG90ZWNoL3dlYmFwcHMvYmVuY2gvc3lzdGVtL2V4cHJlc3Npb25lbmdpbmUvdGVtcGxhdGVzIjt9','YTo5OntzOjIxOiJpbWFnZV9yZXNpemVfcHJvdG9jb2wiO3M6MzoiZ2QyIjtzOjE4OiJpbWFnZV9saWJyYXJ5X3BhdGgiO3M6MDoiIjtzOjE2OiJ0aHVtYm5haWxfcHJlZml4IjtzOjU6InRodW1iIjtzOjE0OiJ3b3JkX3NlcGFyYXRvciI7czo0OiJkYXNoIjtzOjE3OiJ1c2VfY2F0ZWdvcnlfbmFtZSI7czoxOiJuIjtzOjIyOiJyZXNlcnZlZF9jYXRlZ29yeV93b3JkIjtzOjg6ImNhdGVnb3J5IjtzOjIzOiJhdXRvX2NvbnZlcnRfaGlnaF9hc2NpaSI7czoxOiJuIjtzOjIyOiJuZXdfcG9zdHNfY2xlYXJfY2FjaGVzIjtzOjE6InkiO3M6MjM6ImF1dG9fYXNzaWduX2NhdF9wYXJlbnRzIjtzOjE6InkiO30=','YToyOntzOjM5OiIvaG9tZS9qb3Jkb3RlY2gvd2ViYXBwcy9iZW5jaC9pbmRleC5waHAiO3M6MzI6IjQ3NjAwZTRhODJjZjM5NDJiOThmY2E4YmRjOGIyOWEwIjtzOjc6ImVtYWlsZWQiO2E6MDp7fX0=','YToxOntpOjE7YTozOntzOjQ6InVyaXMiO2E6MTQ6e2k6NztzOjEwOiIvd2hvbGVzYWxlIjtpOjk7czo4OiIvY29udGFjdCI7aToxMDtzOjk6Ii9wcm9kdWN0cyI7aToxMTtzOjk6Ii9wcm9ncmFtcyI7aToxMjtzOjE2OiIvbGljZW5zZWQtc3RhdGVzIjtpOjEzO3M6OToiL292ZXJsYXlzIjtpOjE0O3M6MTc6Ii9sb2FuLXN1Ym1pc3Npb25zIjtpOjE1O3M6NzoiL3NpZ251cCI7aToxNjtzOjc6Ii9ndWlkZXMiO2k6MTc7czo2OiIvcmF0ZXMiO2k6MTg7czo2OiIvZm9ybXMiO2k6MTk7czoxMToiL2FwcHJhaXNhbHMiO2k6MjA7czo0OiIvZmFxIjtpOjIxO3M6MTA6Ii9idWxsZXRpbnMiO31zOjk6InRlbXBsYXRlcyI7YToxNDp7aTo3O3M6MToiMSI7aTo5O3M6MToiMSI7aToxMDtzOjE6IjEiO2k6MTE7czoxOiIxIjtpOjEyO3M6MToiMSI7aToxMztzOjE6IjEiO2k6MTQ7czoxOiIxIjtpOjE1O3M6MToiMSI7aToxNjtzOjE6IjEiO2k6MTc7czoxOiIxIjtpOjE4O3M6MToiMSI7aToxOTtzOjE6IjEiO2k6MjA7czoxOiIxIjtpOjIxO3M6MToiMSI7fXM6MzoidXJsIjtzOjI4OiJodHRwOi8vbm9tcmFsLmNvbS9pbmRleC5waHAvIjt9fQ==');
/*!40000 ALTER TABLE `exp_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_snippets`
--

DROP TABLE IF EXISTS `exp_snippets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_snippets` (
  `snippet_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) NOT NULL,
  `snippet_name` varchar(75) NOT NULL,
  `snippet_contents` text,
  PRIMARY KEY  (`snippet_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_snippets`
--

LOCK TABLES `exp_snippets` WRITE;
/*!40000 ALTER TABLE `exp_snippets` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_snippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_specialty_templates`
--

DROP TABLE IF EXISTS `exp_specialty_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_specialty_templates` (
  `template_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `enable_template` char(1) NOT NULL default 'y',
  `template_name` varchar(50) NOT NULL,
  `data_title` varchar(80) NOT NULL,
  `template_data` text NOT NULL,
  PRIMARY KEY  (`template_id`),
  KEY `template_name` (`template_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_specialty_templates`
--

LOCK TABLES `exp_specialty_templates` WRITE;
/*!40000 ALTER TABLE `exp_specialty_templates` DISABLE KEYS */;
INSERT INTO `exp_specialty_templates` VALUES (1,1,'y','offline_template','','<html>\n<head>\n\n<title>System Offline</title>\n\n<style type=\"text/css\">\n\nbody { \nbackground-color:	#ffffff; \nmargin:				50px; \nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size:			11px;\ncolor:				#000;\nbackground-color:	#fff;\n}\n\na {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nletter-spacing:		.09em;\ntext-decoration:	none;\ncolor:			  #330099;\nbackground-color:	transparent;\n}\n  \na:visited {\ncolor:				#330099;\nbackground-color:	transparent;\n}\n\na:hover {\ncolor:				#000;\ntext-decoration:	underline;\nbackground-color:	transparent;\n}\n\n#content  {\nborder:				#999999 1px solid;\npadding:			22px 25px 14px 25px;\n}\n\nh1 {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nfont-size:			14px;\ncolor:				#000;\nmargin-top: 		0;\nmargin-bottom:		14px;\n}\n\np {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		12px;\nmargin-bottom: 		14px;\ncolor: 				#000;\n}\n</style>\n\n</head>\n\n<body>\n\n<div id=\"content\">\n\n<h1>System Offline</h1>\n\n<p>This site is currently offline</p>\n\n</div>\n\n</body>\n\n</html>'),(2,1,'y','message_template','','<html>\n<head>\n\n<title>{title}</title>\n\n<meta http-equiv=\'content-type\' content=\'text/html; charset={charset}\' />\n\n{meta_refresh}\n\n<style type=\"text/css\">\n\nbody { \nbackground-color:	#ffffff; \nmargin:				50px; \nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size:			11px;\ncolor:				#000;\nbackground-color:	#fff;\n}\n\na {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nletter-spacing:		.09em;\ntext-decoration:	none;\ncolor:			  #330099;\nbackground-color:	transparent;\n}\n  \na:visited {\ncolor:				#330099;\nbackground-color:	transparent;\n}\n\na:active {\ncolor:				#ccc;\nbackground-color:	transparent;\n}\n\na:hover {\ncolor:				#000;\ntext-decoration:	underline;\nbackground-color:	transparent;\n}\n\n#content  {\nborder:				#000 1px solid;\nbackground-color: 	#DEDFE3;\npadding:			22px 25px 14px 25px;\n}\n\nh1 {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nfont-size:			14px;\ncolor:				#000;\nmargin-top: 		0;\nmargin-bottom:		14px;\n}\n\np {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		12px;\nmargin-bottom: 		14px;\ncolor: 				#000;\n}\n\nul {\nmargin-bottom: 		16px;\n}\n\nli {\nlist-style:			square;\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		8px;\nmargin-bottom: 		8px;\ncolor: 				#000;\n}\n\n</style>\n\n</head>\n\n<body>\n\n<div id=\"content\">\n\n<h1>{heading}</h1>\n\n{content}\n\n<p>{link}</p>\n\n</div>\n\n</body>\n\n</html>'),(3,1,'y','admin_notify_reg','Notification of new member registration','New member registration site: {site_name}\n\nScreen name: {name}\nUser name: {username}\nEmail: {email}\n\nYour control panel URL: {control_panel_url}'),(4,1,'y','admin_notify_entry','A new channel entry has been posted','A new entry has been posted in the following channel:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nPosted by: {name}\nEmail: {email}\n\nTo read the entry please visit: \n{entry_url}\n'),(5,1,'y','admin_notify_mailinglist','Someone has subscribed to your mailing list','A new mailing list subscription has been accepted.\n\nEmail Address: {email}\nMailing List: {mailing_list}'),(6,1,'y','admin_notify_comment','You have just received a comment','You have just received a comment for the following channel:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nLocated at: \n{comment_url}\n\nPosted by: {name}\nEmail: {email}\nURL: {url}\nLocation: {location}\n\n{comment}'),(7,1,'y','mbr_activation_instructions','Enclosed is your activation code','Thank you for your new member registration.\n\nTo activate your new account, please visit the following URL:\n\n{unwrap}{activation_url}{/unwrap}\n\nThank You!\n\n{site_name}\n\n{site_url}'),(8,1,'y','forgot_password_instructions','Login information','{name},\n\nTo reset your password, please go to the following page:\n\n{reset_url}\n\nYour password will be automatically reset, and a new password will be emailed to you.\n\nIf you do not wish to reset your password, ignore this message. It will expire in 24 hours.\n\n{site_name}\n{site_url}'),(9,1,'y','reset_password_notification','New Login Information','{name},\n\nHere is your new login information:\n\nUsername: {username}\nPassword: {password}\n\n{site_name}\n{site_url}'),(10,1,'y','validated_member_notify','Your membership account has been activated','{name},\n\nYour membership account has been activated and is ready for use.\n\nThank You!\n\n{site_name}\n{site_url}'),(11,1,'y','decline_member_validation','Your membership account has been declined','{name},\n\nWe\'re sorry but our staff has decided not to validate your membership.\n\n{site_name}\n{site_url}'),(12,1,'y','mailinglist_activation_instructions','Email Confirmation','Thank you for joining the \"{mailing_list}\" mailing list!\n\nPlease click the link below to confirm your email.\n\nIf you do not want to be added to our list, ignore this email.\n\n{unwrap}{activation_url}{/unwrap}\n\nThank You!\n\n{site_name}'),(13,1,'y','comment_notification','Someone just responded to your comment','{name_of_commenter} just responded to the entry you subscribed to at:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nYou can see the comment at the following URL:\n{comment_url}\n\n{comment}\n\nTo stop receiving notifications for this comment, click here:\n{notification_removal_url}'),(14,1,'y','comments_opened_notification','New comments have been added','Responses have been added to the entry you subscribed to at:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nYou can see the comments at the following URL:\n{comment_url}\n\n{comments}\n{comment} \n{/comments}\n\nTo stop receiving notifications for this entry, click here:\n{notification_removal_url}'),(15,1,'y','private_message_notification','Someone has sent you a Private Message','\n{recipient_name},\n\n{sender_name} has just sent you a Private Message titled ‘{message_subject}’.\n\nYou can see the Private Message by logging in and viewing your inbox at:\n{site_url}\n\nContent:\n\n{message_content}\n\nTo stop receiving notifications of Private Messages, turn the option off in your Email Settings.\n\n{site_name}\n{site_url}'),(16,1,'y','pm_inbox_full','Your private message mailbox is full','{recipient_name},\n\n{sender_name} has just attempted to send you a Private Message,\nbut your inbox is full, exceeding the maximum of {pm_storage_limit}.\n\nPlease log in and remove unwanted messages from your inbox at:\n{site_url}');
/*!40000 ALTER TABLE `exp_specialty_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_stats`
--

DROP TABLE IF EXISTS `exp_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_stats` (
  `stat_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `total_members` mediumint(7) NOT NULL default '0',
  `recent_member_id` int(10) NOT NULL default '0',
  `recent_member` varchar(50) NOT NULL,
  `total_entries` mediumint(8) NOT NULL default '0',
  `total_forum_topics` mediumint(8) NOT NULL default '0',
  `total_forum_posts` mediumint(8) NOT NULL default '0',
  `total_comments` mediumint(8) NOT NULL default '0',
  `last_entry_date` int(10) unsigned NOT NULL default '0',
  `last_forum_post_date` int(10) unsigned NOT NULL default '0',
  `last_comment_date` int(10) unsigned NOT NULL default '0',
  `last_visitor_date` int(10) unsigned NOT NULL default '0',
  `most_visitors` mediumint(7) NOT NULL default '0',
  `most_visitor_date` int(10) unsigned NOT NULL default '0',
  `last_cache_clear` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`stat_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_stats`
--

LOCK TABLES `exp_stats` WRITE;
/*!40000 ALTER TABLE `exp_stats` DISABLE KEYS */;
INSERT INTO `exp_stats` VALUES (1,1,1,1,'admin',14,0,0,0,1371406560,0,0,1371507688,16,1371493754,1371662395);
/*!40000 ALTER TABLE `exp_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_status_groups`
--

DROP TABLE IF EXISTS `exp_status_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_status_groups` (
  `group_id` int(4) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_status_groups`
--

LOCK TABLES `exp_status_groups` WRITE;
/*!40000 ALTER TABLE `exp_status_groups` DISABLE KEYS */;
INSERT INTO `exp_status_groups` VALUES (1,1,'Statuses');
/*!40000 ALTER TABLE `exp_status_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_status_no_access`
--

DROP TABLE IF EXISTS `exp_status_no_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_status_no_access` (
  `status_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY  (`status_id`,`member_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_status_no_access`
--

LOCK TABLES `exp_status_no_access` WRITE;
/*!40000 ALTER TABLE `exp_status_no_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_status_no_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_statuses`
--

DROP TABLE IF EXISTS `exp_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_statuses` (
  `status_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_id` int(4) unsigned NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_order` int(3) unsigned NOT NULL,
  `highlight` varchar(30) NOT NULL,
  PRIMARY KEY  (`status_id`),
  KEY `group_id` (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_statuses`
--

LOCK TABLES `exp_statuses` WRITE;
/*!40000 ALTER TABLE `exp_statuses` DISABLE KEYS */;
INSERT INTO `exp_statuses` VALUES (1,1,1,'open',1,'009933'),(2,1,1,'closed',2,'990000');
/*!40000 ALTER TABLE `exp_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_template_groups`
--

DROP TABLE IF EXISTS `exp_template_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_template_groups` (
  `group_id` int(6) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_name` varchar(50) NOT NULL,
  `group_order` int(3) unsigned NOT NULL,
  `is_site_default` char(1) NOT NULL default 'n',
  PRIMARY KEY  (`group_id`),
  KEY `site_id` (`site_id`),
  KEY `group_name_idx` (`group_name`),
  KEY `group_order_idx` (`group_order`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_template_groups`
--

LOCK TABLES `exp_template_groups` WRITE;
/*!40000 ALTER TABLE `exp_template_groups` DISABLE KEYS */;
INSERT INTO `exp_template_groups` VALUES (1,1,'main',1,'y');
/*!40000 ALTER TABLE `exp_template_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_template_member_groups`
--

DROP TABLE IF EXISTS `exp_template_member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_template_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `template_group_id` mediumint(5) unsigned NOT NULL,
  PRIMARY KEY  (`group_id`,`template_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_template_member_groups`
--

LOCK TABLES `exp_template_member_groups` WRITE;
/*!40000 ALTER TABLE `exp_template_member_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_template_member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_template_no_access`
--

DROP TABLE IF EXISTS `exp_template_no_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_template_no_access` (
  `template_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY  (`template_id`,`member_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_template_no_access`
--

LOCK TABLES `exp_template_no_access` WRITE;
/*!40000 ALTER TABLE `exp_template_no_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_template_no_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_templates`
--

DROP TABLE IF EXISTS `exp_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_templates` (
  `template_id` int(10) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `group_id` int(6) unsigned NOT NULL,
  `template_name` varchar(50) NOT NULL,
  `save_template_file` char(1) NOT NULL default 'n',
  `template_type` varchar(16) NOT NULL default 'webpage',
  `template_data` mediumtext,
  `template_notes` text,
  `edit_date` int(10) NOT NULL default '0',
  `last_author_id` int(10) unsigned NOT NULL default '0',
  `cache` char(1) NOT NULL default 'n',
  `refresh` int(6) unsigned NOT NULL default '0',
  `no_auth_bounce` varchar(50) NOT NULL default '',
  `enable_http_auth` char(1) NOT NULL default 'n',
  `allow_php` char(1) NOT NULL default 'n',
  `php_parse_location` char(1) NOT NULL default 'o',
  `hits` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`template_id`),
  KEY `group_id` (`group_id`),
  KEY `template_name` (`template_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_templates`
--

LOCK TABLES `exp_templates` WRITE;
/*!40000 ALTER TABLE `exp_templates` DISABLE KEYS */;
INSERT INTO `exp_templates` VALUES (1,1,1,'index','y','webpage','<html>\n<head>\n{embed=\"main/document_head\"}\n</head>\n<body>\n<header></header>\nhello\n<footer></footer>\n</body>\n</html>','',1371158709,1,'n',0,'','n','n','o',1230),(4,1,1,'header','y','static','<div id=\"top_header\" class=\"container\">\n\n    <div class=\"pull-left\">\n        <p>a home loan division of benchmark bank • <b>866.496.7911</b></p>\n    </div>\n\n    <div class=\"pull-right\">\n        <ul>\n            <li><a href=\"https://www.benchmarkbank.com/\" target=\"_blank\">Bank</a></li>\n            <li><a href=\"http://www.affiliatedmortgage.com\" target=\"_blank\">Mortgage</a></li>\n            <li><a href=\"https://www.benchmarkbank.com/personal_banking\" target=\"_blank\">HSA</a></li>\n            <li><a href=\"http://www.benchmarktitleservices.com/\" target=\"_blank\">Title</a></li>\n            <li><a href=\"http://www.affiliatedcorrespondent.com/\"  class=\"active\">AMC</a></li>\n        </ul>\n    </div>\n</div><!-- /#top_header -->\n<div id=\"header\" class=\"navbar\">\n    <div class=\"navbar-inner\">\n        <div class=\"container\">\n            <a class=\"brand\" href=\"/\">\n                <img src=\"{site_url}img/header-logo.png\" alt=\"Affiliate Mortgage Company\" width=\"471\" height=\"104\">\n            </a>\n            <ul class=\"nav pull-right\">\n\n                <li class=\"dropdown first\">\n                    <a href=\"/contact\" role=\"button\" >COMPANY /<br/>Contact INFO</a>\n                </li>\n\n                <li class=\"dropdown\">\n                    <a href=\"#\" role=\"button\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">PRODUCTS <b class=\"caret\"></b></a>\n                    <ul class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"drop3\">\n                        <li><a tabindex=\"-1\" href=\"/products\">PRODUCT LISTING</a></li>\n                        <li><a tabindex=\"-1\" href=\"/overlays\">OVERLAYS</a></li>\n                    </ul>\n                </li>\n                                <li class=\"dropdown\">\n                    <a href=\"/programs\" role=\"button\" >WAREHOUSE PROGRAM</a>\n                </li>\n                                                <li class=\"dropdown\">\n                    <a href=\"faq\" role=\"button\">FAQ</a>\n                </li>\n                <li class=\"dropdown\">\n                    <a href=\"#\" role=\"button\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">RESOURCES <b class=\"caret\"></b></a>\n                    <ul class=\"dropdown-menu\" role=\"menu\" aria-labelledby=\"drop3\">\n                        <li><a tabindex=\"-1\" href=\"/forms\">FORMS</a></li>\n                        <li><a tabindex=\"-1\" href=\"http://www.glo.texas.gov/vlb\" target=\"_blank\">TEXAS VETERANS LAND BOARD</a></li>\n                    </ul>\n                </li>\n            </ul>\n        </div><!-- /.container -->\n    </div>\n</div><!-- /navbar -->\n\n<div id=\"hero\">\n    <img src=\"{site_url}img/hero_amc.jpg\" alt=\"hero_amc\" width=\"1020\" height=\"342\">\n</div><!-- /#hero -->\n','',1371493681,1,'n',0,'','n','n','o',0),(8,1,1,'footer','y','webpage','i\'m the footer','',1371161990,1,'n',0,'','n','n','o',0),(7,1,1,'document_head','y','webpage','<link rel=\"stylesheet\" href=\"{site_url}css/bootstrap.css\" type=\"text/css\" />\n<link rel=\"stylesheet\" href=\"{site_url}css/responsive.css\" type=\"text/css\" />\n<link rel=\"stylesheet\" href=\"{site_url}css/main.css\" type=\"text/css\" />\n<script type=\"text/javascript\" src=\"{site_url}js/custom.js\"></script>\n<script type=\"text/javascript\" src=\"{site_url}js/jquery-1.7.2.min.js\"></script>\n','',1371157609,1,'n',0,'','n','n','o',11),(9,1,1,'page_content','y','webpage','{if segment_1 == \"\"}\n{exp:channel:entries entry_id=\"7\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n<p>{page_body}</p>\n{/exp:channel:entries}\n\n\n\n{if:elseif segment_1 == \"loan-submissions\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n\n{/exp:channel:entries}\n\n{exp:file:entries dynamic=\"no\" directory_id=\"4\" orderby=\"date\"}\n\n<a href=\"{file_url}\">{title}</a>\n{/exp:file:entries}\n\n\n{if:elseif segment_1 == \"rates\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n\n{/exp:channel:entries}\n\n{exp:file:entries dynamic=\"no\" directory_id=\"5\" orderby=\"date\"}\n\n<a href=\"{file_url}\">{title}</a>\n{/exp:file:entries} \n\n\n\n{if:elseif segment_1 == \"overlays\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n{/exp:channel:entries}\n{exp:file:entries dynamic=\"no\" directory_id=\"7\" orderby=\"date\"}\n<a href=\"{file_url}\">{title}</a>\n{/exp:file:entries} \n\n{if:elseif segment_1 == \"forms\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<?php $dir_id = {directory_id}?>\n\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n{page_body}\n{/exp:channel:entries}\n<table class=\"table amc-files\">\n    <tbody>\n        {exp:file:entries dynamic=\"no\" directory_id=\"<?php print 9?>\" orderby=\"date\"}\n            <?php $remainder = {absolute_count} % 2;?>\n            {if <?php print $remainder; ?> == 1}\n        <tr><td>- <a href=\"{file_url}\">{title}</a></td>\n            {if:else}\n            <td>- <a href=\"{file_url}\">{title}</a></td></tr>\n        {/if}\n    {/exp:file:entries} \n</tbody>\n</table>\n\n\n\n{if:elseif segment_1 == \"signup\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n\n{/exp:channel:entries}\n\n{exp:file:entries dynamic=\"no\" directory_id=\"8\" orderby=\"date\"}\n\n<a href=\"{file_url}\">{title}</a>\n{/exp:file:entries} \n\n\n\n\n\n{if:elseif segment_1 == \"appraisals\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n{/exp:channel:entries}\n{exp:file:entries dynamic=\"no\" directory_id=\"3\" orderby=\"date\"}\n<a href=\"{file_url}\">{title}</a>\n{/exp:file:entries} \n\n\n\n\n{if:elseif segment_1 == \"guides\"}\n{exp:channel:entries channel=\"content\" limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n{/exp:channel:entries}\n{exp:file:entries dynamic=\"no\" directory_id=\"6\" orderby=\"date\"}\n<a href=\"{file_url}\">{title}</a>\n{/exp:file:entries}\n\n{if:else}\n\n{exp:channel:entries limit=\"1\"}\n<h1><em>{page_h1}</em></h1>\n<h2>{page_h2}</h2>\n<p>{page_body}</p>\n{/exp:channel:entries}\n\n\n{/if}','',1371349538,1,'n',0,'','n','y','i',0),(10,1,1,'accordion_left','y','webpage','<div class=\"accordion\" id=\"accordion2\">\n  <div class=\"accordion-group\">\n    <div class=\"accordion-heading first\">\n      <a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion2\" href=\"#collapseOne\">\n        Rates and Tools\n      </a>\n    </div>\n    <div id=\"collapseOne\" class=\"accordion-body collapse in\">\n      <div class=\"accordion-inner\">\n        Anim pariatur cliche...\n      </div>\n    </div>\n      \n  </div>\n      <div class=\"accordion-group\">\n    <div class=\"accordion-heading\">\n      <a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion2\" href=\"#collapseTwo\">\n        Licensed States\n      </a>\n    </div>\n  </div>\n  <div class=\"accordion-group\">\n    <div class=\"accordion-heading last\">\n      <a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion2\" href=\"#collapseTwo\">\n        Bulletins\n      </a>\n    </div>\n  </div>\n</div>','',1371224468,1,'n',0,'','n','n','o',0),(11,1,1,'home_content','y','webpage','{exp:channel:entries entry_id=\"7\"}\n<div id=\"main\" class=\"container\">\n\n    <div id=\"mleft\" class=\"amc\">\n\n        <div class=\"body\">\n            {embed=\"main/accordion_left\"}\n        </div>\n    </div><!-- /mleft -->\n    <div id=\"mright\">\n        <div class=\"body\">\n            <h1><em>{page_h1}</em></h1>\n            <h2>{page_h2}</h2>\n            <p>{page_body}</p>\n        </div>\n    </div><!-- /mright -->\n\n</div><!-- /#main -->\n{/exp:channel:entries}',NULL,1371346601,1,'n',0,'','n','n','o',0),(12,1,1,'file-list','y','webpage','','',1371403879,1,'n',0,'','n','n','o',0);
/*!40000 ALTER TABLE `exp_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_throttle`
--

DROP TABLE IF EXISTS `exp_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_throttle` (
  `throttle_id` int(10) unsigned NOT NULL auto_increment,
  `ip_address` varchar(45) NOT NULL default '0',
  `last_activity` int(10) unsigned NOT NULL default '0',
  `hits` int(10) unsigned NOT NULL,
  `locked_out` char(1) NOT NULL default 'n',
  PRIMARY KEY  (`throttle_id`),
  KEY `ip_address` (`ip_address`),
  KEY `last_activity` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_throttle`
--

LOCK TABLES `exp_throttle` WRITE;
/*!40000 ALTER TABLE `exp_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_upload_no_access`
--

DROP TABLE IF EXISTS `exp_upload_no_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_upload_no_access` (
  `upload_id` int(6) unsigned NOT NULL,
  `upload_loc` varchar(3) NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY  (`upload_id`,`member_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_upload_no_access`
--

LOCK TABLES `exp_upload_no_access` WRITE;
/*!40000 ALTER TABLE `exp_upload_no_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_upload_no_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_upload_prefs`
--

DROP TABLE IF EXISTS `exp_upload_prefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_upload_prefs` (
  `id` int(4) unsigned NOT NULL auto_increment,
  `site_id` int(4) unsigned NOT NULL default '1',
  `name` varchar(50) NOT NULL,
  `server_path` varchar(255) NOT NULL default '',
  `url` varchar(100) NOT NULL,
  `allowed_types` varchar(3) NOT NULL default 'img',
  `max_size` varchar(16) default NULL,
  `max_height` varchar(6) default NULL,
  `max_width` varchar(6) default NULL,
  `properties` varchar(120) default NULL,
  `pre_format` varchar(120) default NULL,
  `post_format` varchar(120) default NULL,
  `file_properties` varchar(120) default NULL,
  `file_pre_format` varchar(120) default NULL,
  `file_post_format` varchar(120) default NULL,
  `cat_group` varchar(255) default NULL,
  `batch_location` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_upload_prefs`
--

LOCK TABLES `exp_upload_prefs` WRITE;
/*!40000 ALTER TABLE `exp_upload_prefs` DISABLE KEYS */;
INSERT INTO `exp_upload_prefs` VALUES (4,1,'Loan Submissions','/home/jordotech/webapps/bench/uploads/loan_submissions/','http://nomral.com/uploads/loan_submissions/','all','','','','','','','','','','1',NULL),(3,1,'Appraisals','/home/jordotech/webapps/bench/uploads/appraisals/','http://nomral.com/uploads/appraisals/','all','','','','','','','','','','1',NULL),(5,1,'Rates','/home/jordotech/webapps/bench/uploads/rates/','http://nomral.com/uploads/rates/','all','','','','','','','','','','1',NULL),(6,1,'Guides','/home/jordotech/webapps/bench/uploads/guides/','http://nomral.com/uploads/guides/','all','','','','','','','','','','1',NULL),(7,1,'Overlays','/home/jordotech/webapps/bench/uploads/overlays/','http://nomral.com/uploads/overlays/','all','','','','','','','','','','1',NULL),(8,1,'Signup','/home/jordotech/webapps/bench/uploads/signup/','http://nomral.com/uploads/signup/','all','','','','','','','','','','1',NULL),(9,1,'Forms','/home/jordotech/webapps/bench/uploads/forms/','http://nomral.com/uploads/forms/','all','','','','','','','','','','1',NULL),(10,1,'Bin','/home/jordotech/webapps/bench/uploads/bin/','http://nomral.com/uploads/bin/','all','','','','','','','','','','1',NULL);
/*!40000 ALTER TABLE `exp_upload_prefs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-06-17 22:22:00
